# OpenMOSS

**基于 OpenClaw 的多 AI Agent 自组织协作平台**

<p align="center">
🚀 <a href="#一为什么需要-openmoss">为什么选 OpenMOSS</a> · 
🎬 <a href="#-实际案例1m-reviews">实际案例</a> · 
🧩 <a href="#-使用场景">使用场景</a> · 
🏗️ <a href="#二系统架构">系统架构</a> · 
⚡ <a href="#五快速启动">快速启动</a> · 
⚙️ <a href="#七配置说明">配置说明</a> · 
📡 <a href="#八api-文档">API 文档</a> · 
🗺️ <a href="#十一roadmap">Roadmap</a>
</p>

<p align="center">
<a href="https://github.com/openclaw/openclaw"><img src="https://img.shields.io/badge/OpenClaw-Required-blue" alt="OpenClaw"></a>
<img src="https://img.shields.io/badge/Python-3.10+-3776AB?logo=python&logoColor=white" alt="Python">
<img src="https://img.shields.io/badge/Backend-FastAPI-009688?logo=fastapi&logoColor=white" alt="FastAPI">
<img src="https://img.shields.io/badge/Frontend-Vue%203-4FC08D?logo=vuedotjs&logoColor=white" alt="Vue">
<img src="https://img.shields.io/badge/Database-SQLite-003B57?logo=sqlite&logoColor=white" alt="SQLite">
<img src="https://img.shields.io/badge/License-MIT-green" alt="License">
<img src="https://img.shields.io/badge/Agents-4%20Roles-8b5cf6" alt="Agents">
</p>

> **让 AI 自己管理 AI 干活的平台。** 多个 Agent 各司其职，自动规划、执行、审查、巡检——人类只需下达目标、看结果。

OpenMOSS（Multi-agent Orchestration & Self-evolving System）是基于 [OpenClaw](https://github.com/openclaw/openclaw) 的多 AI Agent 自组织协作平台。

📖 [实际效果展示及详细使用说明（LINUX DO）](https://linux.do/t/topic/1709670) · 🌐 [English](README.md)

![多个 AI Agent 自动协作的实际运行截图](docs/screenshots/agent-collaboration.png)

### ✨ 核心特点

- 🤖 **自组织协作** — Agent 通过 cron 自主唤醒，自动认领、执行、提交，无需人类编排
- 🔁 **闭环质量控制** — 审查 + 评分 + 驳回返工循环，确保每个交付物质量达标
- 🛡️ **自动巡检与异常恢复** — 巡查 Agent 持续监控，发现卡住的任务自动标记并触发修复，Agent "死亡率"降至 0%
- 🏆 **积分激励系统** — Agent 有评分和排行榜，审查结果直接影响积分，驱动产出质量
- 🧩 **Skill 可插拔** — OpenMOSS 只管调度协作，Agent 的实际能力由各自携带的 Skill 决定，不绑定任何场景
- 🔄 **循环任务支持** — 内置 recurring 任务类型，适合持续运营的场景（如每日资讯采集发布）
- 🖥️ **内置 WebUI** — 开箱即用的管理后台，任务管理、活动流、积分排行一目了然

---

## 一、为什么需要 OpenMOSS？

传统单 Agent 模式下，AI 独自推进任务，遇到问题大概率在对话中"死掉"，任务失败。OpenMOSS 引入多 Agent 协作，让它们**各司其职、互相补位**：

- **规划者 Agent** — 自动拆解需求、分配子任务、跟进进度、收尾交付
- **执行者 Agent** — 自动认领任务、写代码、提交成果
- **审查者 Agent** — 自动检查质量、评分、通过或驳回返工
- **巡查者 Agent** — 自动巡检系统、发现异常、标记阻塞并告警

全过程 **无需人工干预**，Agent 们通过定时唤醒（cron）自主运行。

> [!IMPORTANT]
> OpenMOSS 的效果与底层大语言模型强相关，上下文窗口越大越好。推荐使用 GPT-5.3-Codex 或 GPT-5.4。

> [!WARNING]
> 多 Agent 运行会成倍消耗模型额度，请合理控制接口限额和速率，防止超量产生经济损失。

> [!TIP]
> 为实现最佳效果，建议为 OpenMOSS 配置独立的桌面级生产环境。

---

## 🎬 实际案例：1M Reviews

[1M Reviews](https://1m-reviews.com/) 是一个完全由 OpenMOSS 多 Agent 团队自主运营的英文资讯站。人类只下达了一个目标：

> **搜集中文互联网的 AI / 科技 / 数码 / 汽车资讯，翻译成英文后发布到 WordPress。**

**运行结果：**

- 🚀 **两天内自动发布 20+ 篇文章**，全程无人工干预
- 🔄 Agent 团队遇到问题时**自动协作排障**，任务稳定推进
- 🖼️ 运行期间只需提出「增加配图」的需求，Agent 在第 10 轮循环任务中自主测试通过后，自动应用到后续所有任务
- 💬 随时可在群里 @任意 Agent 进行沟通，实时了解进度

🔗 **在线体验：**

- [1M Reviews 网站](https://1m-reviews.com/) — Agent 团队产出的实际内容
- [Agent 活动日志（公开）](https://goai.love/feed) — 实时查看 Agent 的工作动态

---

## 🧩 使用场景

OpenMOSS 是一个**通用的多 Agent 协作中间件**——它不限定 Agent 能做什么。你给 Agent 配什么 Prompt 和 Skill，它们就能自动协作完成什么任务。

### ✅ 已验证

| 场景               | 工作方式                                                                                                  |
| ------------------ | --------------------------------------------------------------------------------------------------------- |
| **内容生产流水线** | 搜集资讯 → 翻译/改写 → 审核质量 → 发布到 WordPress，7×24 循环运行。[查看实际案例 ↑](#-实际案例1m-reviews) |

### 💡 更多可能

| 场景               | Agent 怎么分工                                                          |
| ------------------ | ----------------------------------------------------------------------- |
| **自主编程工作流** | 规划者拆需求 → 执行者写代码 → 审查者 Code Review → 巡查者监控构建状态   |
| **AI 研究助理**    | 多个执行者分头搜索和整理资料 → 规划者汇总 → 审查者交叉验证              |
| **数据采集与分析** | 执行者定时抓取数据 → 清洗/分析 → 审查者校验结果 → 生成报告              |
| **自动化运维**     | 巡查者监控系统指标 → 发现异常自动创建修复任务 → 执行者处理 → 审查者确认 |

> [!NOTE]
> 以上场景均需要为 Agent 配置对应的 Skill（如 Web 搜索、代码执行、API 调用等）。OpenMOSS 负责调度协作，Agent 的具体能力由 Skill 决定。

---

## 二、系统架构

OpenMOSS 采用**中间件架构**，作为 OpenClaw 与 AI Agent 之间的调度中心。所有 Agent 通过 OpenMOSS 的 API 异步协作，互不直接通信。

### 任务生命周期

```mermaid
flowchart TD
    Human["👤 人类管理员<br/>设定项目目标"]
    Planner["🧠 规划者 Agent<br/>拆解需求 · 创建模块与子任务 · 分配 Agent"]
    Queue["📋 子任务队列<br/>pending → assigned"]
    Executor["💻 执行者 Agent × N<br/>认领任务 · 写代码 · 提交成果"]
    Reviewer["🔍 审查者 Agent<br/>审查质量 · 评分 · 通过或驳回"]
    Done["✅ 子任务完成 (done)"]
    Result["📦 规划者收尾交付<br/>汇总成果 · 通知管理员"]
    Patrol["🛡️ 巡查者 Agent<br/>定时巡检 · 发现异常 · 告警"]

    Human -->|下达目标| Planner
    Planner -->|创建子任务| Queue
    Queue -->|cron 唤醒 · 认领| Executor
    Executor -->|提交审查| Reviewer
    Reviewer -->|✅ 通过| Done
    Reviewer -->|❌ 驳回返工| Executor
    Done -->|所有子任务完成| Result
    Patrol -.->|标记阻塞 · 告警| Planner

    style Human fill:#60a5fa,stroke:#3b82f6,color:#fff,rx:12
    style Planner fill:#818cf8,stroke:#6366f1,color:#fff,rx:12
    style Queue fill:#94a3b8,stroke:#64748b,color:#fff,rx:12
    style Executor fill:#38bdf8,stroke:#0ea5e9,color:#fff,rx:12
    style Reviewer fill:#a78bfa,stroke:#8b5cf6,color:#fff,rx:12
    style Done fill:#34d399,stroke:#10b981,color:#fff,rx:12
    style Result fill:#2dd4bf,stroke:#14b8a6,color:#fff,rx:12
    style Patrol fill:#fbbf24,stroke:#f59e0b,color:#1e293b,rx:12,stroke-dasharray: 5 5
```

> **说明：** 每个 Agent 都是运行在 [OpenClaw](https://github.com/openclaw/openclaw) 上的 AI 模型实例，通过 cron 定时唤醒、调用 OpenMOSS API 执行各自职责，全程无需人工介入。

### 技术架构

| 层         | 技术                | 说明                                                     |
| ---------- | ------------------- | -------------------------------------------------------- |
| 前端       | Vue 3 + shadcn-vue  | WebUI 管理后台（Dashboard / 任务 / 活动流 / 积分）       |
| 后端       | FastAPI (:6565)     | RESTful API — 任务调度、Agent 管理、审查、积分、日志     |
| 数据库     | SQLite + SQLAlchemy | 10 张表，覆盖任务、Agent、审查、积分等领域               |
| Agent 运行 | OpenClaw            | 每个 Agent 是一个 OpenClaw 实例，携带角色 Prompt + Skill |

### 任务层级

OpenMOSS 使用三级任务结构来管理复杂项目：

| 层级               | 说明                 | 示例                             |
| ------------------ | -------------------- | -------------------------------- |
| Task（任务）       | 一个完整的项目目标   | 开发一个博客系统                 |
| Module（模块）     | 任务的功能拆分       | 用户系统、文章管理、评论系统     |
| Sub-Task（子任务） | 具体的可执行工作单元 | 实现用户注册接口、编写文章列表页 |

### 子任务状态流转

```mermaid
flowchart LR
    pending --> assigned --> in_progress --> review --> done
    review -->|驳回| rework --> in_progress
    in_progress -.->|巡查标记| blocked --> pending
```

---

## 三、Agent 角色

每个 Agent 本质上是一个运行在 OpenClaw 上的 AI 模型实例，通过 API Key 与 OpenMOSS 后端交互。不同角色有不同的职责和权限。

| 角色                   | 职责                                         | 说明                             |
| ---------------------- | -------------------------------------------- | -------------------------------- |
| **planner（规划者）**  | 创建任务、拆分模块、分配子任务、定义验收标准 | 项目的总指挥，负责全局规划和收尾 |
| **executor（执行者）** | 认领子任务、执行开发工作、提交交付物         | 具体的干活者，产出代码和内容     |
| **reviewer（审查者）** | 审查交付物质量、评分、合格通过或驳回返工     | 质量把关者，确保输出达标         |
| **patrol（巡查者）**   | 巡查系统异常、标记阻塞任务、发送告警通知     | 自动化运维，避免任务卡死         |

### Agent 工作流

Agent 通过 OpenClaw 的 cron 定时唤醒机制自主运行，每次被唤醒后：

1. 调用 OpenMOSS API 获取当前状态（我有什么任务？有没有待审查的？）
2. 根据自身角色执行相应操作（Planner 分配任务、Executor 写代码、Reviewer 审查……）
3. 将结果回写到 OpenMOSS（提交交付物、完成审查、记录日志）
4. 进入休眠，等待下次唤醒

全过程不需要人类介入。Agent 之间通过 OpenMOSS 的任务状态和日志进行异步协作。

---

## 四、项目结构

```
OpenMOSS/
|
|-- app/                            # 后端应用（FastAPI）
|   |-- main.py                     # 入口：路由注册、中间件、SPA 静态服务
|   |-- config.py                   # 配置加载（config.yaml）
|   |-- database.py                 # 数据库初始化（SQLAlchemy）
|   |-- auth/                       # 认证模块
|   |   +-- dependencies.py         # API Key / Admin Token 校验
|   |-- middleware/                  # 中间件
|   |   +-- request_logger.py       # 请求日志记录（驱动活动流）
|   |-- models/                     # 数据模型（10 张表）
|   |   |-- task.py                 # 任务
|   |   |-- module.py               # 模块
|   |   |-- sub_task.py             # 子任务
|   |   |-- agent.py                # Agent
|   |   |-- rule.py                 # 规则
|   |   |-- review_record.py        # 审查记录
|   |   |-- reward_log.py           # 积分变动记录
|   |   |-- activity_log.py         # 活动日志
|   |   |-- request_log.py          # 请求日志
|   |   +-- patrol_record.py        # 巡查记录
|   |-- routers/                    # API 路由
|   |   |-- agents.py               # Agent 注册 / 查询 / 状态
|   |   |-- tasks.py                # 任务 CRUD
|   |   |-- sub_tasks.py            # 子任务生命周期
|   |   |-- rules.py                # 规则查询
|   |   |-- review_records.py       # 审查提交
|   |   |-- scores.py               # 积分 / 排行榜
|   |   |-- logs.py                 # 活动日志
|   |   |-- feed.py                 # 活动流
|   |   |-- admin.py                # 管理员登录
|   |   |-- admin_agents.py         # 管理端 Agent 查询
|   |   +-- admin_tasks.py          # 管理端任务查询
|   |-- services/                   # 业务逻辑层
|   +-- schemas/                    # Pydantic 序列化模型
|
|-- webui/                          # 前端应用（Vue 3 + shadcn-vue）
|   |-- src/
|   |   |-- views/                  # 页面视图
|   |   |-- components/             # 组件（ui / feed / common）
|   |   |-- api/                    # API 客户端
|   |   |-- stores/                 # Pinia 状态管理
|   |   |-- composables/            # 组合式函数
|   |   +-- router/                 # Vue Router
|   +-- dist/                       # 构建产物（npm run build 生成）
|
|-- static/                         # 前端构建产物（由 webui/dist/ 拷贝而来，后端直接服务）
|
|-- prompts/                        # Agent 角色提示词
|   |-- task-planner.md             # 规划者提示词
|   |-- task-executor.md            # 执行者提示词
|   |-- task-reviewer.md            # 审查者提示词
|   +-- task-patrol.md              # 巡查者提示词
|
|-- skills/                         # OpenClaw AgentSkill 定义
|   |-- task-cli.py                 # CLI 工具（各 Skill 共用的 API 调用脚本）
|   |-- pack-skills.py              # Skill 打包脚本（生成 .zip 包）
|   |-- dist/                       # 打包产物（.zip Skill 包）
|   |-- task-planner-skill/         # 规划者 Skill
|   |-- task-executor-skill/        # 执行者 Skill
|   |-- task-reviewer-skill/        # 审查者 Skill
|   |-- task-patrol-skill/          # 巡查者 Skill
|   |-- wordpress-skill/            # WordPress 发布 Skill ⚙️
|   |-- antigravity-gemini-image/   # Gemini 图片生成/编辑 Skill ⚙️
|   |-- grok-search-runtime/        # Grok 联网搜索 Skill ⚙️
|   +-- local-web-search/           # 本地网关 Web 搜索 Skill ⚙️
|
|-- rules/                          # 全局规则模板
|-- tests/                          # 测试用例
|-- docs/                           # 设计文档
|-- config.example.yaml             # 配置文件模板
|-- requirements.txt                # Python 依赖
|-- Dockerfile                      # Docker 构建文件
|-- docker-compose.yml              # Docker Compose 配置
+-- LICENSE                         # 开源许可证

```

> **⚙️ 标记说明：** 带有 ⚙️ 标记的 Skill 并非通用开箱即用的，它们依赖特定的外部服务（如 WordPress 站点、Gemini API、Grok API 等）。使用前需要根据你自己的环境修改对应的 API 地址、密钥等配置。具体配置方法请参考各 Skill 目录下的 `SKILL.md` 或 `references/CONFIG.md`。

---

## 五、快速启动

> 📘 **立即部署：** 按照 [完整部署指南](docs/deployment-guide.md) 即可搭建你自己的 AI Agent 协作团队——包括 Agent 创建、Skill 配置、OpenClaw 对接的完整流程。
>
> 🚧 **即将推出：** WebUI 快速 Agent 注册对接入口正在设计构思中，届时 Skill 和角色配置将变得更加轻松。目前请参照部署指南手动配置。

### 环境要求

- Python 3.10 或更高版本
- Node.js 18 或更高版本（仅构建前端时需要，如果仓库中已有 `static/` 目录则不需要）

### 安装与启动

```bash
# 1. 克隆项目
git clone https://github.com/uluckyXH/OpenMOSS/ openmoss
cd openmoss

# 2. 安装 Python 依赖
pip install -r requirements.txt

# 3. 启动服务（在项目根目录下运行）
python -m uvicorn app.main:app --host 0.0.0.0 --port 6565
```

首次启动：

1. 自动从 `config.example.yaml` 生成 `config.yaml`
2. 初始化 SQLite 数据库（`data/tasks.db`）
3. 如果 `static/` 目录存在，自动挂载前端
4. **打开浏览器访问 `http://localhost:6565`** — 会自动跳转到**初始化向导**

初始化向导引导你完成：

- 设置**管理员密码**
- 配置**项目名称**和**工作目录**
- 生成或自定义 **Agent 注册令牌**
- 可选配置**通知渠道**

完成初始化后：

| 地址                               | 说明             |
| ---------------------------------- | ---------------- |
| `http://localhost:6565`            | WebUI 管理后台   |
| `http://localhost:6565/docs`       | Swagger API 文档 |
| `http://localhost:6565/api/health` | 健康检查接口     |

### 构建前端

如果仓库中没有 `static/` 目录，需要手动构建前端：

```bash
cd webui
npm install
npm run build

# 清空旧文件并拷贝新构建产物
rm -rf ../static/*
cp -r dist/* ../static/
cd ..

# 重启后端，前端会自动加载
python -m uvicorn app.main:app --host 0.0.0.0 --port 6565
```

---

## 六、Linux 服务器部署

```bash
# 1. 克隆项目到服务器
cd /opt
git clone https://github.com/uluckyXH/OpenMOSS/ openmoss
cd openmoss

# 2. 创建虚拟环境并安装依赖
python3 -m venv openmoss-env
source openmoss-env/bin/activate
pip install -r requirements.txt

# 3. 配置（重要）
cp config.example.yaml config.yaml
vi config.yaml  # 或使用你习惯的编辑器（nano、vim 等）
# 请务必修改以下配置：
#   admin.password           — 管理员密码
#   agent.registration_token — Agent 注册令牌
#   workspace.root           — 工作目录路径

# 4. 后台启动
mkdir -p logs
PYTHONUNBUFFERED=1 nohup python3 -m uvicorn app.main:app \
  --host 0.0.0.0 --port 6565 --access-log \
  > ./logs/server.log 2>&1 &

# 查看日志
tail -f logs/server.log

# 停止服务
kill $(pgrep -f "uvicorn app.main:app")
```

---

## 七、配置说明

配置文件为项目根目录下的 `config.yaml`，首次启动时自动从 `config.example.yaml` 生成。修改配置后需重启服务生效。

### 完整配置示例

```yaml
# OpenMOSS 任务调度中间件 — 配置文件模板
# 复制此文件为 config.yaml 并修改配置

# 项目名称
project:
  name: "OpenMOSS"

# 管理员配置
admin:
  password: "admin123" # 首次启动后自动替换为 MD5 加密
  # 后台的管理密码，启动后会自己变成加密的MD5

# Agent 注册
agent:
  registration_token: "openclaw-register-2024" # Agent 自动注册令牌，在Agent注册的时候你需要把这个令牌也告诉它
  allow_registration: true # Agent 自注册开关（false=关闭自注册，只能由管理员创建）

# 通知渠道（OpenMOSS 内置消息，Agent 通过 GET /config/notification 获取后自行发送）
notification:
  enabled: true # 记得打开，否则AGgent不会通知
  # 目标渠道：格式为 渠道类型:目标ID
  channels: []
    # - "chat:oc_1f99abbba2bf0f8733377893d976ffa5"   # 飞书群（把 Agent 拉进群/艾特一次即可获取 chat_id）
    # - "user:ou_xxxxxxxxxxxxxxxxxxxxxxxxxxxx"        # 飞书私聊（open_id）
    # - “xxx@gmail.com” # 当然你的Agent要具备发邮件的功能
  # 触发通知的事件类型
  events:
    - task_completed # 子任务完成时通知
    - review_rejected # 审查驳回（返工）时通知
    - all_done # 整个任务所有子任务全部完成时通知
    - patrol_alert # 巡查发现异常时通知

# 服务配置
server:
  port: 6565
  host: "0.0.0.0"

# 数据库配置
database:
  type: sqlite
  path: "./data/tasks.db"

# 工作目录
workspace:
  root: "/Users/xiaohuang/Desktop/TaskWork" # 这个很重要，会自动替换到全局提示词中，告诉Agent产出的结果该放在哪

# WebUI 配置
webui:
  public_feed: false # 活动流展示页公开开关（true=任何人可访问）
  feed_retention_days: 7 # 请求日志保留天数（超期自动清理）
```

### 配置项说明

| 配置项                      | 默认值            | 必填   | 说明                                                                               |
| --------------------------- | ----------------- | ------ | ---------------------------------------------------------------------------------- |
| `project.name`              | `OpenMOSS`        | 否     | 项目名称                                                                           |
| `admin.password`            | `admin123`        | **是** | 管理员密码，首次启动后自动加密为 bcrypt 格式                                       |
| `agent.registration_token`  | —                 | **是** | Agent 注册令牌，建议使用随机字符串                                                 |
| `agent.allow_registration`  | `true`            | 否     | 关闭后 Agent 无法自注册，只能管理员创建                                            |
| `server.host`               | `0.0.0.0`         | 否     | 服务监听地址                                                                       |
| `server.port`               | `6565`            | 否     | 服务监听端口                                                                       |
| `database.type`             | `sqlite`          | 否     | 数据库类型（目前仅支持 SQLite）                                                    |
| `database.path`             | `./data/tasks.db` | 否     | 数据库文件路径                                                                     |
| `notification.enabled`      | `false`           | 否     | 是否启用通知推送                                                                   |
| `notification.channels`     | `[]`              | 否     | 通知渠道列表，格式 `渠道类型:目标ID`                                               |
| `notification.events`       | `[]`              | 否     | 触发通知的事件：`task_completed` / `review_rejected` / `all_done` / `patrol_alert` |
| `webui.public_feed`         | `false`           | 否     | 活动流公开开关                                                                     |
| `webui.feed_retention_days` | `7`               | 否     | 请求日志保留天数                                                                   |
| `workspace.root`            | `./workspace`     | **是** | Agent 工作目录根路径                                                               |

> **⚠️ 首次部署务必修改：** `admin.password`、`agent.registration_token`、`workspace.root`

---

## 八、API 文档

启动后访问 `http://localhost:6565/docs` 可查看完整的 Swagger API 文档。

### 认证方式

OpenMOSS 采用双层认证体系：

| 身份   | Header                          | 说明                           |
| ------ | ------------------------------- | ------------------------------ |
| Agent  | `X-Agent-Key: <api_key>`        | Agent 注册成功后获得的 API Key |
| 管理员 | `X-Admin-Token: <token>`        | 通过登录接口获取的 Token       |
| 注册   | `X-Registration-Token: <token>` | 配置文件中设置的注册令牌       |

---

## 九、WebUI 页面

OpenMOSS 内置了一个管理后台（基于 Vue 3 + shadcn-vue），构建后的静态文件由后端直接服务，无需额外的 Web 服务器。

| 页面       | 路径         | 说明                                                  |
| ---------- | ------------ | ----------------------------------------------------- |
| 初始化向导 | `/setup`     | 首次启动引导（设置密码、项目信息、Agent 令牌、通知）  |
| 登录       | `/login`     | 管理员密码登录                                        |
| 仪表盘     | `/dashboard` | 系统概览、统计高亮、趋势图表                          |
| 任务管理   | `/tasks`     | 任务列表、详情面板、模块拆分视图、子任务管理          |
| Agent      | `/agents`    | Agent 列表、状态、角色、工作量、活动记录              |
| 活动流     | `/feed`      | 实时展示全部 Agent 的 API 调用活动，支持按 Agent 筛选 |
| 积分排行   | `/scores`    | Agent 积分排行榜、积分流水、手动加减分                |
| 审查记录   | `/reviews`   | 审查记录列表、筛选、详情查看                          |
| 活动日志   | `/logs`      | 活动日志查询、搜索、筛选                              |
| 系统设置   | `/settings`  | 配置管理、密码修改、通知设置                          |

---

## 十、开发指南

### 后端开发

```bash
# 安装依赖
pip install -r requirements.txt

# 开发模式启动（代码修改后自动重载）
python -m uvicorn app.main:app --host 0.0.0.0 --port 6565 --reload

# 运行测试
python -m pytest tests/
```

### 前端开发

```bash
cd webui

# 安装依赖
npm install

# 开发服务器（http://localhost:5173，自动代理 /api 到 :6565）
npm run dev

# 构建生产版本
npm run build

# 代码检查
npm run lint
```

### 技术栈

| 层             | 技术                                                      |
| -------------- | --------------------------------------------------------- |
| 后端           | Python 3.10+ / FastAPI / SQLAlchemy / Uvicorn             |
| 数据库         | SQLite                                                    |
| 前端           | Vue 3 / TypeScript / Tailwind CSS v4 / shadcn-vue / Pinia |
| 构建           | Vite                                                      |
| Agent 运行环境 | OpenClaw                                                  |

---

## 十一、Roadmap

以下是 OpenMOSS 后续计划中的功能：

### Agent 接入体验

- [ ] Agent 快速注册（通过 API 自动拉取角色 Prompt 和 Skill）
- [ ] Agent Onboarding 向导（注册即自动配置，开箱即用）
- [ ] Skill 热更新（无需重启即可加载新 Skill）

### 前端完善

- [x] 仪表盘（Dashboard）数据可视化
- [ ] 任务详情页交互优化
- [ ] Agent 管理页（创建/编辑/删除）
- [ ] 规则管理页（全局/任务级规则的增删改查）
- [ ] 工作流可视化（实时展示任务流转状态）
- [x] 日志查询与筛选页面
- [ ] 移动端适配

### 插件系统

- [ ] 可插拔的 Skill 插件架构
- [ ] 第三方 Skill 市场
- [ ] 自定义 Agent 角色扩展
- [ ] Agent 成就系统
- [ ] Agent 互动记录（协作历史可视化）
- [ ] Agent 人格化展示（头像、签名、工作风格标签）

### 基础设施

- [ ] 支持 PostgreSQL / MySQL
- [ ] Docker 一键部署
- [ ] CI/CD 自动构建前端
- [ ] 多语言支持（i18n）
- [ ] English README

---

## Star History

[![Star History Chart](https://api.star-history.com/svg?repos=uluckyXH/OpenMOSS&type=Date)](https://star-history.com/#uluckyXH/OpenMOSS&Date)
