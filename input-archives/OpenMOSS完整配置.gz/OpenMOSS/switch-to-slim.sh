#!/bin/bash
# 切换到瘦身版提示词脚本

ROLE_DIR="$HOME/OpenMOSS/prompts/role"
SLIM_VERSIONS=("writer-slim.md" "reviewer-slim.md")

echo "=== 切换到瘦身版提示词 ==="
echo ""

# 备份当前状态
CURRENT_BACKUP="$HOME/OpenMOSS/prompts/role-before-slim-$(date +%Y%m%d-%H%M%S)"
cp -r "$ROLE_DIR" "$CURRENT_BACKUP"
echo "✅ 当前状态已备份到：$CURRENT_BACKUP"

# 切换到瘦身版
for slim in "${SLIM_VERSIONS[@]}"; do
    original="${slim%-sllim.md}.md"
    if [ -f "$ROLE_DIR/$slim" ]; then
        # 备份原版本
        cp "$ROLE_DIR/$original" "$ROLE_DIR/${original%.md}-full.md"
        # 替换为瘦身版
        cp "$ROLE_DIR/$slim" "$ROLE_DIR/$original"
        echo "✅ $original 已切换为瘦身版"
    fi
done

echo ""
echo "🚀 已切换到瘦身版提示词！"
echo ""
echo "试点Agent：writer.md, reviewer.md"
echo ""
echo "如需回退，执行：bash $HOME/OpenMOSS/rollback-prompts.sh"
