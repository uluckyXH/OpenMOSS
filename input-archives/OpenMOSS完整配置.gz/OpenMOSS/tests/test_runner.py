#!/usr/bin/env python3
"""
MOSS Agent 集群自动化测试框架
运行所有测试：python3 test_runner.py
"""

import sys
import os
import json
import subprocess
import time
from datetime import datetime
from pathlib import Path

# 测试配置
TEST_CONFIG = {
    "workspace": "/Users/xiaowenzhi/.openclaw/agents/moss/workspace",
    "openmoss_root": "/Users/xiaowenzhi/OpenMOSS",
    "output_dir": "/Users/xiaowenzhi/Desktop/MOSS输出",
    "test_timeout": 30,
}

class Colors:
    """终端颜色"""
    GREEN = '\033[92m'
    RED = '\033[91m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    END = '\033[0m'

class TestRunner:
    """测试运行器"""
    
    def __init__(self):
        self.results = {
            "passed": 0,
            "failed": 0,
            "skipped": 0,
            "total": 0,
            "start_time": datetime.now(),
            "tests": []
        }
    
    def log(self, message, color=Colors.BLUE):
        """打印日志"""
        print(f"{color}{message}{Colors.END}")
    
    def test_file_structure(self):
        """测试文件结构规范"""
        self.log("\n📁 测试文件结构规范...")
        
        required_dirs = [
            "00-系统文档",
            "00-系统文档/01-工作流程",
            "00-系统文档/02-机制说明",
            "00-系统文档/03-Agent配置",
        ]
        
        base_path = Path(TEST_CONFIG["output_dir"])
        errors = []
        
        for dir_name in required_dirs:
            dir_path = base_path / dir_name
            if not dir_path.exists():
                errors.append(f"缺少目录: {dir_name}")
        
        return len(errors) == 0, errors
    
    def test_naming_convention(self):
        """测试命名规范"""
        self.log("\n📝 测试命名规范...")
        
        # 检查最近的文档是否符合命名规范
        base_path = Path(TEST_CONFIG["output_dir"])
        errors = []
        
        # 获取所有 .md 和 .docx 文件
        files = list(base_path.rglob("*.md")) + list(base_path.rglob("*.docx"))
        
        for file in files[:20]:  # 检查最近20个文件
            filename = file.name
            # 检查是否包含时间戳或编号
            if not any(c.isdigit() for c in filename):
                errors.append(f"文件名缺少编号/时间戳: {filename}")
        
        return len(errors) == 0, errors
    
    def test_output_format(self):
        """测试输出格式"""
        self.log("\n📄 测试输出格式...")
        
        # 检查是否有违规的 .md 文件在用户输出目录
        base_path = Path(TEST_CONFIG["output_dir"])
        errors = []
        
        # 排除系统文档目录和源文件备份目录
        for file in base_path.rglob("*.md"):
            # 跳过系统文档和备份
            if "00-系统文档" in str(file) or "99-源文件备份" in str(file):
                continue
            # 检查是否是正文作品（应该为 .docx）
            if "02-正文作品" in str(file):
                errors.append(f"正文作品使用 .md 格式: {file.name}")
        
        return len(errors) == 0, errors
    
    def test_agent_skills(self):
        """测试 Agent Skill 完整性"""
        self.log("\n🤖 测试 Agent Skill 完整性...")
        
        required_skills = [
            "moss-planner-novel",
            "moss-executor-shendu",
            "moss-executor-pachong",
            "moss-executor-character",
            "moss-executor-number",
            "moss-executor-writer",
            "moss-reviewer-novel",
            "moss-executor-mirofish-reader",
            "moss-executor-feedback",
            "moss-executor-hr",
            "moss-patrol-enhanced",
        ]
        
        skills_dir = Path.home() / ".agents" / "skills"
        errors = []
        
        for skill in required_skills:
            skill_path = skills_dir / skill
            if not skill_path.exists():
                errors.append(f"缺少 Skill: {skill}")
            else:
                # 检查 SKILL.md 是否存在
                skill_md = skill_path / "SKILL.md"
                if not skill_md.exists():
                    errors.append(f"Skill 缺少 SKILL.md: {skill}")
        
        return len(errors) == 0, errors
    
    def test_memory_system(self):
        """测试记忆系统"""
        self.log("\n🧠 测试记忆系统...")
        
        errors = []
        
        # 检查 MEMORY.md 是否存在
        memory_file = Path(TEST_CONFIG["workspace"]) / "MEMORY.md"
        if not memory_file.exists():
            errors.append("缺少 MEMORY.md")
        else:
            # 检查是否包含关键内容
            content = memory_file.read_text(encoding='utf-8')
            if "生日" not in content:
                errors.append("MEMORY.md 缺少生日记录")
        
        return len(errors) == 0, errors
    
    def test_cron_jobs(self):
        """测试定时任务"""
        self.log("\n⏰ 测试定时任务...")
        
        cron_dir = Path.home() / ".openclaw" / "cron"
        errors = []
        
        if not cron_dir.exists():
            errors.append("Cron 目录不存在")
        else:
            jobs_file = cron_dir / "jobs.json"
            if not jobs_file.exists():
                errors.append("Cron jobs.json 不存在")
        
        return len(errors) == 0, errors
    
    def test_workflow_integrity(self):
        """测试工作流程完整性"""
        self.log("\n🔄 测试工作流程完整性...")
        
        # 检查 5阶段10步骤 工作流程文档
        workflow_file = Path(TEST_CONFIG["output_dir"]) / "00-系统文档" / "01-工作流程" / "MOSS_完整工作流程.md"
        
        errors = []
        if not workflow_file.exists():
            errors.append("缺少工作流程文档")
        
        return len(errors) == 0, errors
    
    def run_test(self, test_name, test_func):
        """运行单个测试"""
        self.results["total"] += 1
        
        try:
            passed, errors = test_func()
            
            if passed:
                self.results["passed"] += 1
                self.log(f"  ✅ {test_name}", Colors.GREEN)
            else:
                self.results["failed"] += 1
                self.log(f"  ❌ {test_name}", Colors.RED)
                for error in errors:
                    self.log(f"     - {error}", Colors.RED)
            
            self.results["tests"].append({
                "name": test_name,
                "passed": passed,
                "errors": errors if not passed else []
            })
            
        except Exception as e:
            self.results["failed"] += 1
            self.log(f"  💥 {test_name} - 异常: {str(e)}", Colors.RED)
            self.results["tests"].append({
                "name": test_name,
                "passed": False,
                "errors": [str(e)]
            })
    
    def generate_report(self):
        """生成测试报告"""
        end_time = datetime.now()
        duration = (end_time - self.results["start_time"]).total_seconds()
        
        report = {
            "timestamp": end_time.isoformat(),
            "duration_seconds": duration,
            "summary": {
                "total": self.results["total"],
                "passed": self.results["passed"],
                "failed": self.results["failed"],
                "skipped": self.results["skipped"],
                "pass_rate": f"{(self.results['passed'] / self.results['total'] * 100):.1f}%"
            },
            "tests": self.results["tests"]
        }
        
        # 保存报告
        report_dir = Path(TEST_CONFIG["openmoss_root"]) / "tests" / "reports"
        report_dir.mkdir(parents=True, exist_ok=True)
        
        report_file = report_dir / f"test_report_{end_time.strftime('%Y%m%d_%H%M%S')}.json"
        with open(report_file, 'w', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        
        return report, report_file
    
    def print_summary(self, report):
        """打印测试摘要"""
        self.log("\n" + "="*60, Colors.BLUE)
        self.log("📊 测试报告摘要", Colors.BLUE)
        self.log("="*60, Colors.BLUE)
        
        summary = report["summary"]
        self.log(f"总测试数: {summary['total']}")
        self.log(f"通过: {summary['passed']}", Colors.GREEN)
        self.log(f"失败: {summary['failed']}", Colors.RED if summary['failed'] > 0 else Colors.GREEN)
        self.log(f"跳过: {summary['skipped']}", Colors.YELLOW)
        self.log(f"通过率: {summary['pass_rate']}")
        self.log(f"耗时: {report['duration_seconds']:.2f}秒")
        
        if summary['failed'] == 0:
            self.log("\n🎉 所有测试通过！", Colors.GREEN)
        else:
            self.log(f"\n⚠️ 有 {summary['failed']} 个测试失败，需要修复", Colors.RED)
        
        self.log("="*60, Colors.BLUE)
    
    def run_all_tests(self):
        """运行所有测试"""
        self.log("🚀 开始运行 MOSS Agent 集群测试...", Colors.BLUE)
        self.log(f"开始时间: {self.results['start_time'].strftime('%Y-%m-%d %H:%M:%S')}")
        
        # 单元测试
        self.log("\n" + "-"*60, Colors.YELLOW)
        self.log("📦 单元测试", Colors.YELLOW)
        self.log("-"*60, Colors.YELLOW)
        
        self.run_test("文件结构规范", self.test_file_structure)
        self.run_test("命名规范", self.test_naming_convention)
        self.run_test("输出格式规范", self.test_output_format)
        
        # 集成测试
        self.log("\n" + "-"*60, Colors.YELLOW)
        self.log("🔗 集成测试", Colors.YELLOW)
        self.log("-"*60, Colors.YELLOW)
        
        self.run_test("Agent Skill 完整性", self.test_agent_skills)
        self.run_test("记忆系统", self.test_memory_system)
        self.run_test("定时任务", self.test_cron_jobs)
        self.run_test("工作流程完整性", self.test_workflow_integrity)
        
        # 生成报告
        report, report_file = self.generate_report()
        
        # 打印摘要
        self.print_summary(report)
        
        self.log(f"\n📄 详细报告已保存: {report_file}")
        
        # 返回退出码
        return 0 if report["summary"]["failed"] == 0 else 1


if __name__ == "__main__":
    runner = TestRunner()
    exit_code = runner.run_all_tests()
    sys.exit(exit_code)
