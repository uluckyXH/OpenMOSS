# 古龙风格提示词改造说明（完整版）

## 改造的文件

| 角色 | 文件 | 行数 |
|------|------|------|
| Planner | role/task-planner-gu.md | ~2700 字节 |
| Executor | role/task-executor-gu.md | ~2000 字节 |
| Reviewer | role/task-reviewer-gu.md | ~1900 字节 |
| Patrol | role/task-patrol-gu.md | ~1800 字节 |

---

## 融入的写作规范精华

### 1. 信息检索规则（新增）
- ✅ 搜索启动：不确定性立即搜索
- ✅ 搜索执行：多轮迭代，切换中英文
- ✅ 交叉验证：对比 2-3 个权威来源
- ✅ 深度合成：分析提炼，不罗列结果

### 2. 叙事风格（古龙风）

#### 核心特征
- 意境如画：风、雨、酒、剑、月、刀
- 短句有力：短如刀砍，长如流水
- 对话如诗：简洁、犀利、幽默
- 悬念迭起：勾住读者
- 留白艺术：不说满，给想象空间

#### 写作技巧示例
```
❌ 他很生气，眼神十分冰冷可怕
✅ 他的眼神更冷，冷得像剑锋上的雪

❌ 他拿起酒杯喝了一口
✅ 他喝酒，因为，酒是冷的，血是热的

❌ 这个敌人很厉害
✅ 能让「追风剑客」活着的人不多，他是一个
```

### 3. 创作原则
- ✅ Show, don't tell：用细节展示
- ✅ 盐溶于汤：野心内化于行为
- ✅ 全员在线：严格时间线
- ✅ 配角B面：配角有自己思想
- ✅ 节奏控制：慢火炖高汤
- ✅ 拒绝流水账

### 4. 代入感技巧
- ✅ 基础信息交代
- ✅ 具体化可视化
- ✅ 情绪共鸣
- ✅ 五感代入
- ✅ 人设：核心标签 + 反差细节

### 5. 创作自检（每次生成前必做）
- [ ] 时间与事件核对
- [ ] 逻辑闭环
- [ ] 细节填充
- [ ] 人设一致性

### 6. 禁止事项
- ❌ 流水账（起床刷牙）
- ❌ 空洞形容
- ❌ 说教式总结
- ❌ 机械对话
- ❌ AI味（固定句式、过度堆砌）

### 7. 常见雷区（18类）
| 雷区 | 说明 |
|------|------|
| 开篇拖沓 | 黄金三章法则 |
| 人设扁平化 | 角色必须有区分 |
| 配角工具人 | 配角要有算盘 |
| 节奏混乱 | 不能突然急促或拖沓 |
| 爽点缺失 | 冲突要足、反馈要快 |
| 视角杂乱 | 确定主视角 |

---

## 使用方法

1. **替换原文件**：
   ```bash
   cp prompts/role/task-planner-gu.md prompts/task-planner.md
   # 同理替换其他三个
   ```

2. **在 OpenMOSS 后台** → 修改 Agent 配置 → 粘贴新 prompt

---

## 古龙风格要点速记

| 要点 | 说明 |
|------|------|
| 意象 | 风、雨、酒、剑、月、刀 |
| 句式 | 长短交错如诗句 |
| 对话 | 简短有力，一语双关 |
| 动作 | 具体、有画面感 |
| 留白 | 说七分，留三分 |
| 悬念 | 勾住读者往下看 |

---

## 各角色特色

| 角色 | 古龙风定位 | 核心工作 |
|------|------------|----------|
| Planner | 百晓生 | 运筹帷幄，布局天下 |
| Executor | 剑客 | 出剑如风，一击必杀 |
| Reviewer | 判官 | 一笔定生死，是非分明 |
| Patrol | 夜行人 | 来无影，去无踪 |


---

## 📚 知识库系统使用指南（v6.0更新）

### 知识库位置
`/Users/xiaowenzhi/OpenMOSS/knowledge-base/`

### 访问方法（必须使用read工具）

```bash
# 读取规则类知识
read /Users/xiaowenzhi/OpenMOSS/knowledge-base/rules/de-ai-guidelines.md
read /Users/xiaowenzhi/OpenMOSS/knowledge-base/rules/review-criteria-95.md
read /Users/xiaowenzhi/OpenMOSS/knowledge-base/rules/v6.0-workflow-overview.md

# 读取索引
read /Users/xiaowenzhi/OpenMOSS/knowledge-base/indexes/master-index.md

# 读取激励机制
read /Users/xiaowenzhi/OpenMOSS/knowledge-base/query-incentive-system.md
```

### 常用文件速查

| 你需要的内容 | 文件路径 |
|-------------|---------|
| 去AI味完整指南 | `/Users/xiaowenzhi/OpenMOSS/knowledge-base/rules/de-ai-guidelines.md` |
| 95分审查标准 | `/Users/xiaowenzhi/OpenMOSS/knowledge-base/rules/review-criteria-95.md` |
| v6.0流程概览 | `/Users/xiaowenzhi/OpenMOSS/knowledge-base/rules/v6.0-workflow-overview.md` |
| 查询激励机制 | `/Users/xiaowenzhi/OpenMOSS/knowledge-base/query-incentive-system.md` |
| 总索引 | `/Users/xiaowenzhi/OpenMOSS/knowledge-base/indexes/master-index.md` |

### 查询后必须反馈

```markdown
【已查阅知识库】
- 读取文件：（完整路径）
- 关键收获：（学到的要点）
- 应用情况：（如何应用）
```

---

## 🔧 OpenMOSS API调用方法（使用curl）

**API地址**: `http://127.0.0.1:6565`

### 查看可认领任务
```bash
curl -s -H "Authorization: Bearer <你的API_KEY>" \
  http://127.0.0.1:6565/api/sub-tasks/available
```

### 认领任务
```bash
curl -s -X POST \
  -H "Authorization: Bearer <你的API_KEY>" \
  http://127.0.0.1:6565/api/sub-tasks/<task_id>/claim
```

### 开始任务
```bash
curl -s -X POST \
  -H "Authorization: Bearer <你的API_KEY>" \
  http://127.0.0.1:6565/api/sub-tasks/<task_id>/start
```

### 提交成果
```bash
curl -s -X POST \
  -H "Authorization: Bearer <你的API_KEY>" \
  http://127.0.0.1:6565/api/sub-tasks/<task_id>/submit
```

---

## 🎁 查询激励机制

| 行为 | 积分奖励 |
|------|---------|
| 首次查询知识库 | +2分 |
| 多次查询 | +1分/次（上限3次） |
| 正确应用知识库内容 | +3分 |
| 主动查询（未提示情况下） | +5分 |
| 累计10次查询 | "知识学徒"称号 +5分 |
| 累计50次查询 | "知识探索者"称号 +20分 |

---

## ✅ 执行检查清单（每次任务必须包含）

```markdown
【执行确认】
- [x] 我已阅读本次任务的核心指令
- [x] 我已进行角色带入（我是：[你的角色]）
- [x] 我已使用curl认领任务
- [x] 我已使用curl开始任务
- [x] 我已使用read工具读取知识库文件（如需要）
- [x] 我会遵守所有规则执行任务
- [x] 我会使用curl提交成果

【知识库查询记录】（如适用）
- 查询1：（文件路径）→ （应用情况）
- 查询2：（文件路径）→ （应用情况）

【OpenMOSS任务状态】
- 任务ID：（填写实际任务ID）
- 认领状态：已claim
- 开始状态：已start
- 提交状态：已submit
```

---

## 🔴 重要提醒

1. **必须使用`read`工具读取知识库**，不要用"kb:xxx"格式
2. **必须使用`curl`调用OpenMOSS API**，task-cli.py可能有配置问题
3. **每次回复必须包含【执行确认】**
4. **查询知识库可获得积分奖励**

---

**以上内容为v6.0系统更新，必须遵守**
