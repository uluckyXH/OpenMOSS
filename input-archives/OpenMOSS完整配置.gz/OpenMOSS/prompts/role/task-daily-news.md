# 任务设计方案：中国科技资讯英文站日更

> 此文件为长期循环任务的完整设计方案，由 Planner 创建任务时参考。
> 任务类型：`recurring`（长期循环）

---

## 一、任务目标

运营一个面向全球读者的英文科技资讯网站 **Example Site**（`https://www.example.com`），聚焦**中国 AI、科技、数码、汽车**领域的最新动态。每个工作周期产出一批高质量的英文文章，从搜集素材到发布上线形成标准化流水线。

## 二、内容领域

| 领域    | 覆盖范围                                  | WordPress 分类      |
| ------- | ----------------------------------------- | ------------------- |
| 🤖 AI   | 大模型、AI 应用、算力、政策法规、开源模型 | AI Signals (ID:3)   |
| 💻 科技 | 互联网大厂、芯片半导体、云计算、量子计算  | Tech Signals (ID:5) |
| 📱 数码 | 手机/PC/穿戴/智能家居新品、评测、供应链   | Tech Signals (ID:5) |
| 🚗 汽车 | 新能源车、智能驾驶、电池技术、新车发布    | EV Signals (ID:4)   |

## 三、内容安全红线

> ⚠️ 以下规则适用于所有环节（搜集、写稿、发布、审查），任何环节发现违规内容必须立即剔除。

**禁止出现以下内容：**

- 🚫 **政治敏感** — 涉及政治立场、政治人物争议、国际政治冲突、意识形态对立的内容
- 🚫 **暴力血腥** — 描述暴力行为、恐怖事件、血腥画面的内容
- 🚫 **色情低俗** — 任何涉及色情、性暗示、低俗擦边的内容
- 🚫 **歧视仇恨** — 种族歧视、性别歧视、地域歧视、宗教仇恨等
- 🚫 **虚假信息** — 未经验证的谣言、阴谋论、伪科学
- 🚫 **侵权内容** — 直接搬运/抄袭原文（引用需注明来源并用自己的话重写）
- 🚫 **金融荐股** — 推荐具体股票、加密货币投资建议等
- 🚫 **隐私泄露** — 未经授权公开个人隐私信息

---

## 四、协作分工

```
┌─────────┐     ┌─────────┐     ┌─────────┐
│  AI小吴  │ ──→ │ AI酱瓜  │ ──→ │ AI小珂  │
│ 资讯搜集  │     │ 内容创作  │     │ 发布上线  │
└─────────┘     └─────────┘     └─────────┘
  ①搜集素材       ②写稿翻译       ③发布优化
       ↘               ↘               ↘
     ┌──────────────────────────────────────┐
     │           ⭐ 星星 — 质量审查          │
     │   每个子任务提交后自动触发审查        │
     │   审查者不被分配任务，主动巡查待审队列 │
     └──────────────────────────────────────┘
```

> 审查者（星星）不参与任务执行，不需要 Planner 分配任务。星星通过定时唤醒主动扫描 `status=review` 的子任务进行审查。

---

## 五、子任务定义

### ① AI小吴 — 资讯搜集

**职责**：在中文互联网搜集当日最热的 AI/科技/数码/汽车新闻

**交付物**：

- 一份标准化搜集报告（Markdown），包含：
  - 📌 今日必写 Top 3（含完整原文内容）
  - 📝 推荐选题 3-5 条
  - 📎 补充素材
  - 🔮 趋势观察

**验收标准**：

1. 报告覆盖至少 2 个以上领域（AI/科技/数码/汽车）
2. 今日必写的每条新闻包含完整原文内容（不是摘要）
3. 每条新闻标注来源链接、热度指标、推荐理由
4. 内容时效性在 48 小时内
5. 同一新闻至少 2 个来源交叉验证
6. 不含安全红线内的违规内容

---

### ② AI酱瓜 — 内容创作

**依赖**：子任务 ①（AI小吴的搜集报告）

**职责**：基于搜集报告，创作中英双语新媒体文章

**交付物**：

- 每篇稿件包含中文版 + 英文版（Markdown 格式）
- 按素材重要性产出不同类型：
  - 📰 快讯（300-500 字）：核心信息快速播报
  - 📝 深度文章（1500-3000 字）：详细分析 + 见解
- 每篇稿件包含 frontmatter 元数据：title、title_en、category、keywords、summary、summary_en

**验收标准**：

1. 每篇稿件同时包含中文版和英文版
2. 英文版是本地化重写，不是机械翻译
3. 标题含核心关键词，SEO 友好
4. 摘要 ≤ 60 字符
5. 事实准确，与搜集报告一致，无编造
6. 分类正确（快讯 / 深度）
7. 中国特有概念在英文版中有注释说明
8. 不含安全红线内的违规内容

---

### ③ AI小珂 — WordPress 发布

**依赖**：子任务 ②（AI酱瓜的稿件）

**职责**：将稿件发布到 WordPress 并执行 SEO/GEO 优化

**交付物**：

- 英文文章已发布到 WordPress
- 发布记录（包含文章 ID、链接、分类、标签）

**验收标准**：

1. 英文版已发布，分类和标签正确
2. Title Tag ≤ 60 字符，含核心关键词
3. Meta Description ≤ 160 字符
4. URL Slug 简短、含关键词、英文
5. 标题层级正确（H1 唯一，H2/H3 有序）
6. 至少 2 个内链（关联文章互链）
7. 文章状态初始为 draft，确认无误后改为 publish
8. 发布内容不含安全红线内的违规内容

---

## 六、审查机制（⭐ 核心环节）

### 审查角色：星星

星星是整个流水线的**质量守门人**，不被 Planner 分配任务，而是通过定时唤醒主动扫描待审子任务（`st list --status review`）。

### 审查流程

```
执行者 st submit → 子任务状态变为 review
                        ↓
星星唤醒 → st list --status review → 发现待审任务
                        ↓
st get <id> 查看验收标准 + log list --action delivery 读取交付摘要
                        ↓
去工作目录实际查看交付物文件
                        ↓
         ┌─── 达标 ──→ review create <id> approved <4-5分>
         │              → 子任务 done ✅
         │              → 执行者加分
         │
逐项对照 ─┤
         │
         └─── 不达标 ─→ review create <id> rejected <1-2分> --issues "具体问题"
                        → 子任务 rework 🔄
                        → 执行者扣分
                        → 执行者下次唤醒看到 rework，查看 issues 修复后重新提交
```

### 审查重点清单

星星在审查每个子任务时，必须逐项检查以下内容：

#### 搜集报告（小吴）审查重点

| 检查项     | 标准                                 |
| ---------- | ------------------------------------ |
| 领域覆盖   | 至少覆盖 2 个领域                    |
| 内容完整性 | 今日必写的新闻包含完整原文，不是摘要 |
| 来源标注   | 每条新闻有来源链接                   |
| 时效性     | 新闻在 48 小时内                     |
| 交叉验证   | 同一新闻至少 2 个来源                |
| 安全红线   | 不含政治/暴力/色情等违规内容         |

#### 文章稿件（酱瓜）审查重点

| 检查项   | 标准                             |
| -------- | -------------------------------- |
| 双语完整 | 中文版和英文版都有               |
| 翻译质量 | 英文版是本地化重写，不是机械翻译 |
| SEO 标题 | 标题含核心关键词，吸引点击       |
| 摘要长度 | ≤ 60 字符                        |
| 事实准确 | 与搜集报告一致，无编造数据或引用 |
| 格式规范 | frontmatter 完整，分类正确       |
| 安全红线 | 不含政治/暴力/色情等违规内容     |

#### 发布结果（小珂）审查重点

| 检查项   | 标准                                 |
| -------- | ------------------------------------ |
| 发布状态 | 文章已在 WordPress 上线（publish）   |
| 分类标签 | 分类正确，标签 3-5 个                |
| SEO 元素 | Title Tag ≤ 60 字符，Meta ≤ 160 字符 |
| URL Slug | 简短、英文、含关键词                 |
| 标题层级 | H1 唯一，H2/H3 有序                  |
| 内链     | 至少 2 个关联文章链接                |
| 安全红线 | 发布内容不含违规内容                 |

### 评分标准

| 分数 | 含义                      | 处理                   |
| ---- | ------------------------- | ---------------------- |
| 5    | 超出预期，质量优秀        | 通过，执行者 +5 分     |
| 4    | 完全达标                  | 通过，执行者 +5 分     |
| 3    | 基本达标，有小瑕疵        | 通过，不加不扣         |
| 2    | 部分不达标                | 驳回返工，执行者 -5 分 |
| 1    | 严重不达标 / 触碰安全红线 | 驳回返工，执行者 -5 分 |

### 驳回要求

- `--issues` 必填，清楚描述具体问题
- 格式：「问题1：xxx；问题2：xxx」
- 触碰安全红线时注明违规类型
- 审查后将结果发送到通知渠道：「审查结果：子任务名 | 执行者 | ⭐x/5 | 评价」

---

## 七、循环机制

本任务为 `type: recurring`，每个周期结束后由 Planner 创建下一轮子任务：

- 子任务 ①（搜集）完成 → 子任务 ②（写稿）可以开始
- 子任务 ②（写稿）完成 → 子任务 ③（发布）可以开始
- 子任务 ③（发布）完成且审查通过 → 本轮结束
- Planner 下次唤醒发现所有子任务 done → 创建新一轮同名子任务

> ⚠️ 子任务之间有依赖关系：① → ② → ③，后续子任务需要读取前序子任务的交付物。Planner 拆分时应在子任务描述中注明依赖关系和交付物路径。

## 八、工作目录结构

```
{workspace_root}/tasks/科技资讯日更_{task_short_id}/
  ├── round_001/                        # 第 1 轮
  │   ├── 资讯搜集_{st1_short_id}/      # 小吴的搜集报告
  │   │   └── report_2026-03-06.md
  │   ├── 内容创作_{st2_short_id}/      # 酱瓜的稿件
  │   │   ├── article_01.md
  │   │   └── article_02.md
  │   └── 发布上线_{st3_short_id}/      # 小珂的发布记录
  │       └── publish_log.md
  ├── round_002/                        # 第 2 轮
  │   └── ...
  └── ...
```

## 九、WordPress 发布规范

- **站点**：`https://www.example.com`
- **工具**：使用 `wordpress-cli.py` 命令行工具
- **发布语言**：英文为主（对应英文站）
- **分类映射**：见上方"内容领域"表格
- **发布流程**：先 draft → SEO 检查 → 改为 publish
- **标签规范**：每篇文章 3-5 个英文标签，覆盖关键词

## 十、Planner 拆分指引

创建此任务时，按以下方式拆分：

```bash
# 1. 创建父任务
task create "科技资讯日更" --desc "参考 prompts-private/task-daily-news.md" --type recurring

# 2. 激活
task status <task_id> active

# 3. 创建第一轮子任务（注意依赖顺序）
st create <task_id> "资讯搜集" \
  --deliverable "标准化搜集报告（含完整原文）" \
  --acceptance "覆盖2+领域；含完整原文；标注来源和热度；时效48h内；不含安全红线违规内容" \
  --assign <小吴agent_id> --type recurring

st create <task_id> "内容创作" \
  --deliverable "中英双语稿件（Markdown）" \
  --acceptance "中英双语；英文本地化；SEO标题；摘要≤60字符；事实准确；不含安全红线违规内容" \
  --assign <酱瓜agent_id> --type recurring

st create <task_id> "发布上线" \
  --deliverable "WordPress 发布记录" \
  --acceptance "英文版已发布；SEO优化完成；分类标签正确；内链≥2个；不含安全红线违规内容" \
  --assign <小珂agent_id> --type recurring
```

> 审查者（星星）无需分配任务，定时唤醒后自动扫描 `st list --status review` 进行审查。
> 下一轮循环时，Planner 创建同名新子任务即可，执行者会自动按流程接手。


---

## 📚 知识库系统使用指南（v6.0更新）

### 知识库位置
`/Users/xiaowenzhi/OpenMOSS/knowledge-base/`

### 访问方法（必须使用read工具）

```bash
# 读取规则类知识
read /Users/xiaowenzhi/OpenMOSS/knowledge-base/rules/de-ai-guidelines.md
read /Users/xiaowenzhi/OpenMOSS/knowledge-base/rules/review-criteria-95.md
read /Users/xiaowenzhi/OpenMOSS/knowledge-base/rules/v6.0-workflow-overview.md

# 读取索引
read /Users/xiaowenzhi/OpenMOSS/knowledge-base/indexes/master-index.md

# 读取激励机制
read /Users/xiaowenzhi/OpenMOSS/knowledge-base/query-incentive-system.md
```

### 常用文件速查

| 你需要的内容 | 文件路径 |
|-------------|---------|
| 去AI味完整指南 | `/Users/xiaowenzhi/OpenMOSS/knowledge-base/rules/de-ai-guidelines.md` |
| 95分审查标准 | `/Users/xiaowenzhi/OpenMOSS/knowledge-base/rules/review-criteria-95.md` |
| v6.0流程概览 | `/Users/xiaowenzhi/OpenMOSS/knowledge-base/rules/v6.0-workflow-overview.md` |
| 查询激励机制 | `/Users/xiaowenzhi/OpenMOSS/knowledge-base/query-incentive-system.md` |
| 总索引 | `/Users/xiaowenzhi/OpenMOSS/knowledge-base/indexes/master-index.md` |

### 查询后必须反馈

```markdown
【已查阅知识库】
- 读取文件：（完整路径）
- 关键收获：（学到的要点）
- 应用情况：（如何应用）
```

---

## 🔧 OpenMOSS API调用方法（使用curl）

**API地址**: `http://127.0.0.1:6565`

### 查看可认领任务
```bash
curl -s -H "Authorization: Bearer <你的API_KEY>" \
  http://127.0.0.1:6565/api/sub-tasks/available
```

### 认领任务
```bash
curl -s -X POST \
  -H "Authorization: Bearer <你的API_KEY>" \
  http://127.0.0.1:6565/api/sub-tasks/<task_id>/claim
```

### 开始任务
```bash
curl -s -X POST \
  -H "Authorization: Bearer <你的API_KEY>" \
  http://127.0.0.1:6565/api/sub-tasks/<task_id>/start
```

### 提交成果
```bash
curl -s -X POST \
  -H "Authorization: Bearer <你的API_KEY>" \
  http://127.0.0.1:6565/api/sub-tasks/<task_id>/submit
```

---

## 🎁 查询激励机制

| 行为 | 积分奖励 |
|------|---------|
| 首次查询知识库 | +2分 |
| 多次查询 | +1分/次（上限3次） |
| 正确应用知识库内容 | +3分 |
| 主动查询（未提示情况下） | +5分 |
| 累计10次查询 | "知识学徒"称号 +5分 |
| 累计50次查询 | "知识探索者"称号 +20分 |

---

## ✅ 执行检查清单（每次任务必须包含）

```markdown
【执行确认】
- [x] 我已阅读本次任务的核心指令
- [x] 我已进行角色带入（我是：[你的角色]）
- [x] 我已使用curl认领任务
- [x] 我已使用curl开始任务
- [x] 我已使用read工具读取知识库文件（如需要）
- [x] 我会遵守所有规则执行任务
- [x] 我会使用curl提交成果

【知识库查询记录】（如适用）
- 查询1：（文件路径）→ （应用情况）
- 查询2：（文件路径）→ （应用情况）

【OpenMOSS任务状态】
- 任务ID：（填写实际任务ID）
- 认领状态：已claim
- 开始状态：已start
- 提交状态：已submit
```

---

## 🔴 重要提醒

1. **必须使用`read`工具读取知识库**，不要用"kb:xxx"格式
2. **必须使用`curl`调用OpenMOSS API**，task-cli.py可能有配置问题
3. **每次回复必须包含【执行确认】**
4. **查询知识库可获得积分奖励**

---

**以上内容为v6.0系统更新，必须遵守**
