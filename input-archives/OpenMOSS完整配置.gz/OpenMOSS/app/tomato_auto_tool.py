#!/usr/bin/env python3
"""
番茄小说数据自动化工具
功能：
1. 自动抓取番茄后台数据
2. 每日自动生成数据报告
3. 异常自动预警
4. 竞品数据监控

使用方法：
    python3 tomato_auto_tool.py --help
    python3 tomato_auto_tool.py --daily-report
    python3 tomato_auto_tool.py --monitor
"""

import json
import os
import sys
import argparse
from datetime import datetime, timedelta
from pathlib import Path

# 配置
CONFIG = {
    "data_dir": "~/OpenMOSS/data/tomato",
    "report_dir": "~/OpenMOSS/reports/tomato",
    "log_dir": "~/OpenMOSS/logs/tomato",
    "alert_webhook": "",  # 飞书/微信 webhook
    "check_interval": 3600,  # 监控间隔(秒)
}

# 数据文件路径
DATA_FILE = Path(CONFIG["data_dir"]).expanduser() / "book_data.json"
REPORT_FILE = Path(CONFIG["report_dir"]).expanduser() / f"daily_report_{datetime.now().strftime('%Y%m%d')}.md"


class TomatoDataTool:
    """番茄小说数据自动化工具"""
    
    def __init__(self):
        self.data_dir = Path(CONFIG["data_dir"]).expanduser()
        self.report_dir = Path(CONFIG["report_dir"]).expanduser()
        self.log_dir = Path(CONFIG["log_dir"]).expanduser()
        
        # 创建目录
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.report_dir.mkdir(parents=True, exist_ok=True)
        self.log_dir.mkdir(parents=True, exist_ok=True)
    
    def log(self, message: str, level: str = "INFO"):
        """日志记录"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_line = f"[{timestamp}] [{level}] {message}"
        print(log_line)
        
        log_file = self.log_dir / f"tomato_{datetime.now().strftime('%Y%m%d')}.log"
        with open(log_file, "a", encoding="utf-8") as f:
            f.write(log_line + "\n")
    
    def load_book_data(self) -> dict:
        """加载书籍数据"""
        if DATA_FILE.exists():
            with open(DATA_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        return {}
    
    def save_book_data(self, data: dict):
        """保存书籍数据"""
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        self.log("书籍数据已保存")
    
    def fetch_data(self, book_id: str = None) -> dict:
        """
        抓取番茄后台数据
        注意：实际需要登录番茄小说作者后台API
        这里提供模拟数据结构和接口
        """
        self.log(f"开始抓取书籍数据: {book_id or '所有书籍'}")
        
        # TODO: 实际实现需要调用番茄小说API
        # 模拟数据
        mock_data = {
            "book_id": book_id or "demo_book",
            "book_name": "示例小说",
            "update_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "data": {
                "total_words": 150000,  # 总字数
                "today_words": 6000,     # 今日更新
                "read_count": 85000,    # 阅读人数
                "finish_rate": 18.5,    # 读完率(%)
                "bookshelf_rate": 25.0, # 书架率(%)
                "follow_rate": 45.0,    # 追更率(%)
                "comment_count": 1250,  # 评论数
                "like_count": 8500,     # 点赞数
                "reward_count": 320,    # 送礼数
                "today_income": 128.5,  # 今日收入(元)
                "month_income": 2850.0, # 本月收入(元)
            }
        }
        
        self.log("数据抓取完成", "SUCCESS")
        return mock_data
    
    def analyze_data(self, data: dict) -> dict:
        """数据分析"""
        self.log("开始数据分析")
        
        d = data.get("data", {})
        
        # 关键指标分析
        analysis = {
            "health_score": 0,  # 健康度评分
            "warnings": [],     # 警告
            "suggestions": [],  # 建议
            "trend": "stable",  # 趋势
        }
        
        # 读完率分析
        finish_rate = d.get("finish_rate", 0)
        if finish_rate < 10:
            analysis["health_score"] -= 30
            analysis["warnings"].append("读完率低于10%，建议大改或切书")
            analysis["suggestions"].append("检查开篇是否足够吸引")
        elif finish_rate < 20:
            analysis["health_score"] -= 10
            analysis["warnings"].append("读完率偏低（20%以下）")
            analysis["suggestions"].append("加强爽点密度，优化节奏")
        
        # 追更率分析
        follow_rate = d.get("follow_rate", 0)
        if follow_rate < 30:
            analysis["health_score"] -= 20
            analysis["warnings"].append("追更率低于30%")
            analysis["suggestions"].append("加强章末Hook设计")
        
        # 书架率分析
        bookshelf_rate = d.get("bookshelf_rate", 0)
        if bookshelf_rate < 15:
            analysis["health_score"] -= 15
            analysis["warnings"].append("书架率偏低")
            analysis["suggestions"].append("增加人物魅力，提升读者代入感")
        
        # 日更分析
        today_words = d.get("today_words", 0)
        if today_words < 4000:
            analysis["health_score"] -= 10
            analysis["warnings"].append("今日更新不足4000字")
            analysis["suggestions"].append("加快更新节奏，保持全勤")
        
        # 计算健康度（满分100）
        analysis["health_score"] = max(0, 100 + analysis["health_score"])
        
        # 状态评估
        if analysis["health_score"] >= 80:
            analysis["status"] = "优秀"
        elif analysis["health_score"] >= 60:
            analysis["status"] = "良好"
        elif analysis["health_score"] >= 40:
            analysis["status"] = "警告"
        else:
            analysis["status"] = "危险"
        
        self.log(f"数据分析完成: 健康度 {analysis['health_score']}", "SUCCESS")
        return analysis
    
    def generate_report(self, data: dict, analysis: dict) -> str:
        """生成日报"""
        self.log("生成数据日报")
        
        d = data.get("data", {})
        
        report = f"""# 番茄小说数据日报

**生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  
**书籍**: {data.get('book_name', 'N/A')}

---

## 📊 核心数据

| 指标 | 数值 | 状态 |
|------|------|------|
| 总字数 | {d.get('total_words', 0):,} | {'✅' if d.get('total_words', 0) > 50000 else '🟡'} |
| 今日更新 | {d.get('today_words', 0):,} | {'✅' if d.get('today_words', 0) >= 4000 else '❌'} |
| 阅读人数 | {d.get('read_count', 0):,} | {'✅' if d.get('read_count', 0) > 50000 else '🟡'} |
| 读完率 | {d.get('finish_rate', 0)}% | {'✅' if d.get('finish_rate', 0) > 20 else '🟡' if d.get('finish_rate', 0) > 10 else '❌'} |
| 书架率 | {d.get('bookshelf_rate', 0)}% | {'✅' if d.get('bookshelf_rate', 0) > 20 else '🟡'} |
| 追更率 | {d.get('follow_rate', 0)}% | {'✅' if d.get('follow_rate', 0) > 40 else '🟡' if d.get('follow_rate', 0) > 30 else '❌'} |

---

## 💰 收入数据

| 指标 | 数值 |
|------|------|
| 今日收入 | ¥{d.get('today_income', 0):.2f} |
| 本月收入 | ¥{d.get('month_income', 0):.2f} |

---

## ❤️ 互动数据

| 指标 | 数值 |
|------|------|
| 评论数 | {d.get('comment_count', 0):,} |
| 点赞数 | {d.get('like_count', 0):,} |
| 送礼数 | {d.get('reward_count', 0):,} |

---

## 📈 健康度评估

**综合评分**: {analysis.get('health_score', 0)}/100  
**状态**: {analysis.get('status', '未知')}

### ⚠️ 警告
{chr(10).join(['- ' + w for w in analysis.get('warnings', [])]) if analysis.get('warnings') else '无'}

### 💡 建议
{chr(10).join(['- ' + s for s in analysis.get('suggestions', [])]) if analysis.get('suggestions') else '无'}

---

## 🔧 快捷操作

```bash
# 查看详细数据
python3 tomato_auto_tool.py --book BOOK_ID

# 实时监控
python3 tomato_auto_tool.py --monitor

# 生成完整报告
python3 tomato_auto_tool.py --full-report
```

---

*由 MOSS 自动化工具生成*
"""
        
        return report
    
    def save_report(self, report: str) -> Path:
        """保存报告"""
        REPORT_FILE.parent.mkdir(parents=True, exist_ok=True)
        with open(REPORT_FILE, "w", encoding="utf-8") as f:
            f.write(report)
        self.log(f"报告已保存: {REPORT_FILE}")
        return REPORT_FILE
    
    def send_alert(self, analysis: dict):
        """发送预警"""
        if analysis.get("warnings"):
            self.log("发送预警通知", "WARNING")
            # TODO: 实现飞书/微信 webhook 通知
            # 这里预留接口
            pass
    
    def daily_report(self):
        """生成每日报告"""
        self.log("=" * 50)
        self.log("开始生成每日报告")
        self.log("=" * 50)
        
        # 抓取数据
        data = self.fetch_data()
        
        # 保存原始数据
        book_data = self.load_book_data()
        book_data[data["book_id"]] = data
        self.save_book_data(book_data)
        
        # 数据分析
        analysis = self.analyze_data(data)
        
        # 生成报告
        report = self.generate_report(data, analysis)
        
        # 保存报告
        report_path = self.save_report(report)
        
        # 预警检查
        if analysis.get("warnings"):
            self.send_alert(analysis)
        
        self.log("每日报告生成完成", "SUCCESS")
        return report_path
    
    def monitor(self, interval: int = None):
        """实时监控模式"""
        interval = interval or CONFIG["check_interval"]
        self.log(f"启动实时监控，间隔 {interval} 秒")
        self.log("按 Ctrl+C 停止")
        
        try:
            while True:
                self.daily_report()
                import time
                time.sleep(interval)
        except KeyboardInterrupt:
            self.log("监控已停止")
    
    def compare_competitors(self, competitor_ids: list):
        """竞品对比分析"""
        self.log("开始竞品对比分析")
        
        competitors = []
        for cid in competitor_ids:
            data = self.fetch_data(cid)
            analysis = self.analyze_data(data)
            competitors.append({
                "book_id": cid,
                "data": data.get("data", {}),
                "analysis": analysis
            })
        
        # 生成对比报告
        report = "# 竞品对比分析\n\n"
        for cp in competitors:
            d = cp["data"]
            report += f"""## {cp['book_id']}

| 指标 | 数值 |
|------|------|
| 读完率 | {d.get('finish_rate', 0)}% |
| 追更率 | {d.get('follow_rate', 0)}% |
| 书架率 | {d.get('bookshelf_rate', 0)}% |
| 今日收入 | ¥{d.get('today_income', 0):.2f} |

"""
        
        # 保存报告
        report_file = self.report_dir / f"competitor_{datetime.now().strftime('%Y%m%d')}.md"
        with open(report_file, "w", encoding="utf-8") as f:
            f.write(report)
        
        self.log(f"竞品报告已保存: {report_file}")
        return report_file


def main():
    parser = argparse.ArgumentParser(description="番茄小说数据自动化工具")
    parser.add_argument("--daily-report", action="store_true", help="生成每日报告")
    parser.add_argument("--monitor", action="store_true", help="实时监控模式")
    parser.add_argument("--book", type=str, help="指定书籍ID")
    parser.add_argument("--competitors", nargs="+", help="竞品书籍ID列表")
    parser.add_argument("--interval", type=int, default=3600, help="监控间隔(秒)")
    parser.add_argument("--full-report", action="store_true", help="生成完整报告")
    
    args = parser.parse_args()
    
    tool = TomatoDataTool()
    
    if args.daily_report:
        tool.daily_report()
    elif args.monitor:
        tool.monitor(args.interval)
    elif args.competitors:
        tool.compare_competitors(args.competitors)
    elif args.full_report:
        data = tool.fetch_data(args.book)
        analysis = tool.analyze_data(data)
        report = tool.generate_report(data, analysis)
        print(report)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
