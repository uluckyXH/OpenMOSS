"""
Agent 消息路由
"""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from typing import Optional, List

from app.database import get_db
from app.auth.dependencies import get_current_agent
from app.models.agent import Agent
from app.services import message_service


router = APIRouter(prefix="/messages", tags=["Message"])


# ============================================================
# 请求/响应模型
# ============================================================

class MessageSendRequest(BaseModel):
    to_agent: str = Field(..., description="接收者 Agent ID")
    type: str = Field(..., description="消息类型: notification/complete/rework/alarm/info")
    content: str = Field(..., description="消息内容")
    extra_data: Optional[dict] = Field(None, description="附加数据")


class MessageResponse(BaseModel):
    id: str
    from_agent: str
    to_agent: str
    type: str
    content: str
    extra_data: Optional[dict]
    is_read: bool
    created_at: str

    class Config:
        from_attributes = True


class MessageListResponse(BaseModel):
    messages: List[MessageResponse]
    unread_count: int


class BroadcastRequest(BaseModel):
    type: str = Field(..., description="消息类型")
    content: str = Field(..., description="消息内容")
    extra_data: Optional[dict] = Field(None, description="附加数据")


# ============================================================
# API 端点
# ============================================================

@router.post("", response_model=MessageResponse, summary="发送消息")
async def send_message(
    req: MessageSendRequest,
    agent: Agent = Depends(get_current_agent),
    db: Session = Depends(get_db),
):
    """向指定 Agent 发送消息"""
    try:
        message = message_service.send_message(
            db,
            from_agent=agent.id,
            to_agent=req.to_agent,
            msg_type=req.type,
            content=req.content,
            metadata=req.extra_data,
        )
        return message
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/mine", response_model=MessageListResponse, summary="获取我的消息")
async def get_my_messages(
    unread_only: bool = False,
    msg_type: Optional[str] = None,
    limit: int = 50,
    agent: Agent = Depends(get_current_agent),
    db: Session = Depends(get_db),
):
    """获取发给我的消息"""
    messages, unread_count = message_service.list_messages(
        db,
        agent_id=agent.id,
        unread_only=unread_only,
        msg_type=msg_type,
        limit=limit,
    )
    return {
        "messages": [MessageResponse.model_validate(m) for m in messages],
        "unread_count": unread_count,
    }


@router.post("/{message_id}/read", response_model=MessageResponse, summary="标记已读")
async def mark_read(
    message_id: str,
    agent: Agent = Depends(get_current_agent),
    db: Session = Depends(get_db),
):
    """标记消息为已读"""
    try:
        message = message_service.mark_as_read(db, message_id, agent.id)
        return message
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/read-all", summary="全部标记已读")
async def mark_all_read(
    agent: Agent = Depends(get_current_agent),
    db: Session = Depends(get_db),
):
    """将所有未读消息标记为已读"""
    count = message_service.mark_all_as_read(db, agent.id)
    return {"message": f"已标记 {count} 条消息为已读"}


@router.get("/{message_id}", response_model=MessageResponse, summary="获取单条消息")
async def get_message(
    message_id: str,
    agent: Agent = Depends(get_current_agent),
    db: Session = Depends(get_db),
):
    """获取单条消息详情"""
    message = message_service.get_message(db, message_id)
    if not message:
        raise HTTPException(status_code=404, detail="消息不存在")
    return message


@router.delete("/{message_id}", summary="删除消息")
async def delete_message(
    message_id: str,
    agent: Agent = Depends(get_current_agent),
    db: Session = Depends(get_db),
):
    """删除消息（只能删除发给自己的）"""
    try:
        message_service.delete_message(db, message_id, agent.id)
        return {"message": "删除成功"}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/broadcast", summary="广播消息")
async def broadcast(
    req: BroadcastRequest,
    agent: Agent = Depends(get_current_agent),
    db: Session = Depends(get_db),
):
    """广播消息给所有 Agent（自己除外）"""
    try:
        messages = message_service.broadcast_message(
            db,
            from_agent=agent.id,
            msg_type=req.type,
            content=req.content,
            exclude_agents=[agent.id],  # 不发给自己
            metadata=req.extra_data,
        )
        return {"message": f"已发送给 {len(messages)} 个 Agent"}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
