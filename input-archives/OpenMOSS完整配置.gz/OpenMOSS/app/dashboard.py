#!/usr/bin/env python3
"""
MOSS Agent 集群日志仪表盘
实时监控和分析
"""

import json
import os
import sys
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Any

# 添加 app 目录到路径
sys.path.insert(0, "/Users/xiaowenzhi/OpenMOSS/app")
from logger import get_aggregator

class Colors:
    """终端颜色"""
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    END = '\033[0m'
    BOLD = '\033[1m'

class LogDashboard:
    """日志仪表盘"""
    
    def __init__(self):
        self.aggregator = get_aggregator()
        self.colors = Colors()
    
    def print_header(self, title: str):
        """打印标题"""
        print(f"\n{self.colors.BOLD}{self.colors.HEADER}{'='*70}{self.colors.END}")
        print(f"{self.colors.BOLD}{self.colors.HEADER} {title}{self.colors.END}")
        print(f"{self.colors.BOLD}{self.colors.HEADER}{'='*70}{self.colors.END}")
    
    def print_section(self, title: str):
        """打印章节"""
        print(f"\n{self.colors.CYAN}{title}{self.colors.END}")
        print(f"{self.colors.CYAN}{'-'*70}{self.colors.END}")
    
    def show_overview(self):
        """显示概览"""
        self.print_header("MOSS Agent 集群日志仪表盘")
        
        stats = self.aggregator.get_stats()
        
        print(f"\n📅 日期: {stats['date']}")
        print(f"📝 总日志数: {self.colors.BOLD}{stats['total_logs']}{self.colors.END}")
        
        # 级别分布
        self.print_section("📊 日志级别分布")
        total = sum(stats['by_level'].values())
        if total > 0:
            for level, count in stats['by_level'].items():
                if count > 0:
                    percentage = (count / total) * 100
                    bar = '█' * int(percentage / 5)
                    color = self.colors.GREEN if level == 'INFO' else (
                        self.colors.YELLOW if level == 'WARNING' else 
                        self.colors.RED if level == 'ERROR' else self.colors.BLUE
                    )
                    print(f"  {level:8} {color}{bar:20}{self.colors.END} {count:4} ({percentage:.1f}%)")
        
        # Agent 分布
        if stats['by_agent']:
            self.print_section("🤖 Agent 分布")
            for agent, count in sorted(stats['by_agent'].items(), key=lambda x: x[1], reverse=True):
                print(f"  {agent:20} {count:4} 条日志")
    
    def show_recent_errors(self, limit: int = 5):
        """显示最近的错误"""
        errors = self.aggregator.query(level="ERROR", limit=limit)
        
        if errors:
            self.print_section(f"🚨 最近 {len(errors)} 个错误")
            for error in errors:
                time = error['timestamp'][11:19]  # HH:MM:SS
                agent = error['agent_name']
                message = error['message']
                print(f"  {self.colors.RED}[{time}] {agent}: {message}{self.colors.END}")
                if error.get('data'):
                    print(f"    详情: {json.dumps(error['data'], ensure_ascii=False)[:100]}")
        else:
            print(f"\n{self.colors.GREEN}✅ 最近没有错误{self.colors.END}")
    
    def show_recent_tasks(self, limit: int = 10):
        """显示最近的任务"""
        # 查询任务相关日志
        all_logs = self.aggregator.query(limit=100)
        tasks = [log for log in all_logs if log['level'] in ['TASK_START', 'TASK_END']][:limit]
        
        if tasks:
            self.print_section(f"📋 最近任务活动")
            for task in tasks:
                time = task['timestamp'][11:19]
                level = task['level']
                agent = task['agent_name']
                
                if level == 'TASK_START':
                    task_id = task.get('data', {}).get('task_id', 'unknown')
                    task_type = task.get('data', {}).get('task_type', 'unknown')
                    print(f"  {self.colors.BLUE}[{time}]{self.colors.END} {agent:15} ▶️  开始 {task_type}: {task_id}")
                else:
                    task_id = task.get('data', {}).get('task_id', 'unknown')
                    status = task.get('data', {}).get('status', 'unknown')
                    duration = task.get('data', {}).get('duration_ms', 0)
                    status_color = self.colors.GREEN if status == '成功' else self.colors.RED
                    print(f"  {self.colors.BLUE}[{time}]{self.colors.END} {agent:15} {status_color}⏹  完成 {task_id}: {status} ({duration}ms){self.colors.END}")
    
    def show_decisions(self, limit: int = 5):
        """显示最近的决策"""
        all_logs = self.aggregator.query(limit=100)
        decisions = [log for log in all_logs if log['level'] == 'DECISION'][:limit]
        
        if decisions:
            self.print_section(f"🤔 最近 {len(decisions)} 个决策")
            for decision in decisions:
                time = decision['timestamp'][11:19]
                agent = decision['agent_name']
                decision_type = decision.get('data', {}).get('decision_type', 'unknown')
                choice = decision.get('data', {}).get('decision', 'unknown')
                reason = decision.get('data', {}).get('reason', 'unknown')
                print(f"  {self.colors.YELLOW}[{time}]{self.colors.END} {agent:15} {decision_type}")
                print(f"      选择: {self.colors.GREEN}{choice}{self.colors.END}")
                print(f"      原因: {reason}")
    
    def show_realtime(self, duration: int = 30):
        """实时显示（持续 duration 秒）"""
        self.print_header("实时日志监控")
        print(f"⏱️  持续监控 {duration} 秒，按 Ctrl+C 退出\n")
        
        last_count = 0
        import time
        
        try:
            start_time = time.time()
            while time.time() - start_time < duration:
                stats = self.aggregator.get_stats()
                current_count = stats['total_logs']
                
                if current_count > last_count:
                    new_logs = current_count - last_count
                    print(f"\r{self.colors.GREEN}● {datetime.now().strftime('%H:%M:%S')} 新增 {new_logs} 条日志{self.colors.END}", end='', flush=True)
                    last_count = current_count
                
                time.sleep(1)
                
        except KeyboardInterrupt:
            print(f"\n\n{self.colors.YELLOW}监控已停止{self.colors.END}")
    
    def export_report(self, output_path: str = None):
        """导出报告"""
        if output_path is None:
            output_path = f"/Users/xiaowenzhi/Desktop/MOSS输出/00-系统文档/03-Agent配置/logs_report_{datetime.now().strftime('%Y%m%d')}.json"
        
        stats = self.aggregator.get_stats()
        recent_errors = self.aggregator.query(level="ERROR", limit=20)
        
        report = {
            "generated_at": datetime.now().isoformat(),
            "stats": stats,
            "recent_errors": recent_errors,
            "summary": {
                "health_score": self._calculate_health_score(stats),
                "recommendations": self._generate_recommendations(stats)
            }
        }
        
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        
        print(f"\n{self.colors.GREEN}📄 报告已导出: {output_path}{self.colors.END}")
        return output_path
    
    def _calculate_health_score(self, stats: Dict) -> int:
        """计算健康分数"""
        score = 100
        
        total = stats['total_logs']
        if total > 0:
            error_rate = stats['by_level'].get('ERROR', 0) / total
            warning_rate = stats['by_level'].get('WARNING', 0) / total
            
            score -= int(error_rate * 100)  # 错误率每1%扣1分
            score -= int(warning_rate * 50)  # 警告率每2%扣1分
        
        return max(0, min(100, score))
    
    def _generate_recommendations(self, stats: Dict) -> List[str]:
        """生成建议"""
        recommendations = []
        
        if stats['by_level'].get('ERROR', 0) > 0:
            recommendations.append("发现错误日志，建议立即排查")
        
        if stats['by_level'].get('WARNING', 0) > 10:
            recommendations.append("警告日志较多，建议检查系统状态")
        
        if stats['total_logs'] == 0:
            recommendations.append("今日无日志记录，请检查日志系统是否正常工作")
        
        return recommendations
    
    def run(self):
        """运行仪表盘"""
        self.show_overview()
        self.show_recent_errors()
        self.show_recent_tasks()
        self.show_decisions()
        
        # 计算健康分数
        stats = self.aggregator.get_stats()
        health_score = self._calculate_health_score(stats)
        
        print(f"\n{self.colors.BOLD}{'='*70}{self.colors.END}")
        color = self.colors.GREEN if health_score >= 90 else (
            self.colors.YELLOW if health_score >= 70 else self.colors.RED
        )
        print(f"🏥 系统健康度: {color}{health_score}/100{self.colors.END}")
        print(f"{self.colors.BOLD}{'='*70}{self.colors.END}\n")


def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description='MOSS Agent 集群日志仪表盘')
    parser.add_argument('--realtime', '-r', action='store_true', help='实时监控模式')
    parser.add_argument('--export', '-e', action='store_true', help='导出报告')
    parser.add_argument('--duration', '-d', type=int, default=30, help='实时监控持续时间(秒)')
    
    args = parser.parse_args()
    
    dashboard = LogDashboard()
    
    if args.realtime:
        dashboard.show_realtime(args.duration)
    elif args.export:
        dashboard.export_report()
    else:
        dashboard.run()


if __name__ == "__main__":
    main()
