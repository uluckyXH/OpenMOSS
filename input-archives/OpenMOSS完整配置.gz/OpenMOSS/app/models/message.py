"""
Agent 消息表模型
"""
import uuid
from datetime import datetime
from sqlalchemy import Column, String, Text, Boolean, DateTime, ForeignKey, JSON, Index

from app.database import Base


class AgentMessage(Base):
    __tablename__ = "agent_message"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    from_agent = Column(String(36), ForeignKey("agent.id"), nullable=False, comment="发送者 ID")
    to_agent = Column(String(36), ForeignKey("agent.id"), nullable=False, comment="接收者 ID")
    type = Column(String(20), nullable=False, comment="消息类型: notification/complete/rework/alarm/info")
    content = Column(Text, nullable=False, comment="消息内容")
    extra_data = Column(JSON, nullable=True, comment="附加数据（任务ID、章节号等）")
    is_read = Column(Boolean, default=False, comment="是否已读")
    created_at = Column(DateTime, default=datetime.now, comment="创建时间")

    # 复合索引：按接收者查询未读消息
    __table_args__ = (
        Index("ix_message_to_agent", "to_agent", "is_read"),
        Index("ix_message_created", "created_at"),
    )
