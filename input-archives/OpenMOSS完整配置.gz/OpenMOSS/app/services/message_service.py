"""
Agent 消息服务
"""
import uuid
from datetime import datetime
from typing import List, Optional
from sqlalchemy.orm import Session

from app.models.message import AgentMessage
from app.models.agent import Agent


# 消息类型
MESSAGE_TYPES = ["notification", "complete", "rework", "alarm", "info"]


def send_message(
    db: Session,
    from_agent: str,
    to_agent: str,
    msg_type: str,
    content: str,
    metadata: dict = None,
    auto_commit: bool = True,
) -> AgentMessage:
    """发送消息"""
    # 校验接收者存在
    to_agent_obj = db.query(Agent).filter(Agent.id == to_agent).first()
    if not to_agent_obj:
        raise ValueError(f"接收者 Agent {to_agent} 不存在")

    # 校验消息类型
    if msg_type not in MESSAGE_TYPES:
        raise ValueError(f"消息类型必须是: {', '.join(MESSAGE_TYPES)}")

    message = AgentMessage(
        id=str(uuid.uuid4()),
        from_agent=from_agent,
        to_agent=to_agent,
        type=msg_type,
        content=content,
        extra_data=metadata,
    )
    db.add(message)
    if auto_commit:
        db.commit()
        db.refresh(message)
    else:
        db.flush()
    return message


def list_messages(
    db: Session,
    agent_id: str,
    unread_only: bool = False,
    msg_type: str = None,
    limit: int = 50,
) -> tuple:
    """获取某 Agent 的消息列表，返回 (messages, unread_count)"""
    query = db.query(AgentMessage).filter(AgentMessage.to_agent == agent_id)

    if unread_only:
        query = query.filter(AgentMessage.is_read == False)
    if msg_type:
        query = query.filter(AgentMessage.type == msg_type)

    # 未读总数（不受 limit 影响）
    unread_count = db.query(AgentMessage).filter(
        AgentMessage.to_agent == agent_id,
        AgentMessage.is_read == False,
    ).count()

    messages = query.order_by(AgentMessage.created_at.desc()).limit(limit).all()
    return messages, unread_count


def mark_as_read(db: Session, message_id: str, agent_id: str) -> AgentMessage:
    """标记消息为已读（只能标记发给自己的消息）"""
    message = db.query(AgentMessage).filter(
        AgentMessage.id == message_id,
        AgentMessage.to_agent == agent_id,
    ).first()
    if not message:
        raise ValueError(f"消息 {message_id} 不存在或不属于你")

    message.is_read = True
    db.commit()
    db.refresh(message)
    return message


def mark_all_as_read(db: Session, agent_id: str) -> int:
    """将所有未读消息标记为已读，返回标记数量"""
    count = db.query(AgentMessage).filter(
        AgentMessage.to_agent == agent_id,
        AgentMessage.is_read == False,
    ).update({"is_read": True})
    db.commit()
    return count


def get_message(db: Session, message_id: str) -> Optional[AgentMessage]:
    """获取单条消息"""
    return db.query(AgentMessage).filter(AgentMessage.id == message_id).first()


def broadcast_message(
    db: Session,
    from_agent: str,
    msg_type: str,
    content: str,
    exclude_agents: list = None,
    metadata: dict = None,
) -> List[AgentMessage]:
    """广播消息给所有 Agent（排除指定列表）"""
    # 获取所有 Agent
    query = db.query(Agent.id)
    if exclude_agents:
        query = query.filter(~Agent.id.in_(exclude_agents))

    agent_ids = [row[0] for row in query.all()]

    messages = []
    for agent_id in agent_ids:
        msg = send_message(
            db=db,
            from_agent=from_agent,
            to_agent=agent_id,
            msg_type=msg_type,
            content=content,
            metadata=metadata,
            auto_commit=False,  # 批量插入，最后统一提交
        )
        messages.append(msg)

    db.commit()
    return messages


def delete_message(db: Session, message_id: str, agent_id: str) -> bool:
    """删除消息（只能删除发给自己的消息）"""
    message = db.query(AgentMessage).filter(
        AgentMessage.id == message_id,
        AgentMessage.to_agent == agent_id,
    ).first()
    if not message:
        raise ValueError(f"消息 {message_id} 不存在或不属于你")

    db.delete(message)
    db.commit()
    return True
