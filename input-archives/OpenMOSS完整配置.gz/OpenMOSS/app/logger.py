#!/usr/bin/env python3
"""
MOSS Agent 集群统一日志系统
结构化日志 + 集中收集
"""

import json
import logging
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional
import uuid

# 日志配置
LOG_CONFIG = {
    "level": "INFO",
    "format": "json",
    "output_dir": "/Users/xiaowenzhi/OpenMOSS/logs",
    "max_file_size": 10 * 1024 * 1024,  # 10MB
    "backup_count": 5,
}

class StructuredLogger:
    """结构化日志记录器"""
    
    def __init__(self, agent_id: str, agent_name: str):
        self.agent_id = agent_id
        self.agent_name = agent_name
        self.trace_id = str(uuid.uuid4())[:8]
        
        # 确保日志目录存在
        self.log_dir = Path(LOG_CONFIG["output_dir"])
        self.log_dir.mkdir(parents=True, exist_ok=True)
        
        # 初始化日志文件
        self.log_file = self.log_dir / f"{agent_name}_{datetime.now().strftime('%Y%m%d')}.log"
        
    def _log(self, level: str, message: str, **kwargs):
        """内部日志方法"""
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "level": level,
            "agent_id": self.agent_id,
            "agent_name": self.agent_name,
            "trace_id": self.trace_id,
            "message": message,
            "data": kwargs if kwargs else {}
        }
        
        # 写入文件
        with open(self.log_file, 'a', encoding='utf-8') as f:
            f.write(json.dumps(log_entry, ensure_ascii=False) + '\n')
        
        # 控制台输出（开发模式）
        if LOG_CONFIG["format"] == "pretty":
            print(f"[{log_entry['timestamp']}] [{level}] {self.agent_name}: {message}")
        
        return log_entry
    
    def debug(self, message: str, **kwargs):
        """调试日志"""
        return self._log("DEBUG", message, **kwargs)
    
    def info(self, message: str, **kwargs):
        """信息日志"""
        return self._log("INFO", message, **kwargs)
    
    def warning(self, message: str, **kwargs):
        """警告日志"""
        return self._log("WARNING", message, **kwargs)
    
    def error(self, message: str, **kwargs):
        """错误日志"""
        return self._log("ERROR", message, **kwargs)
    
    def task_start(self, task_id: str, task_type: str, **kwargs):
        """任务开始"""
        return self._log("TASK_START", f"开始任务: {task_id}", 
                        task_id=task_id, task_type=task_type, **kwargs)
    
    def task_end(self, task_id: str, status: str, duration_ms: int, **kwargs):
        """任务结束"""
        return self._log("TASK_END", f"完成任务: {task_id}",
                        task_id=task_id, status=status, 
                        duration_ms=duration_ms, **kwargs)
    
    def decision(self, decision_type: str, decision: str, reason: str, **kwargs):
        """决策记录"""
        return self._log("DECISION", f"决策: {decision_type}",
                        decision_type=decision_type,
                        decision=decision,
                        reason=reason, **kwargs)


class LogAggregator:
    """日志聚合器"""
    
    def __init__(self):
        self.log_dir = Path(LOG_CONFIG["output_dir"])
    
    def query(self, 
              start_time: Optional[datetime] = None,
              end_time: Optional[datetime] = None,
              agent_name: Optional[str] = None,
              level: Optional[str] = None,
              limit: int = 100) -> list:
        """查询日志"""
        results = []
        
        # 获取所有日志文件
        log_files = list(self.log_dir.glob("*.log"))
        
        for log_file in log_files:
            # 过滤文件
            if agent_name and agent_name not in log_file.name:
                continue
            
            with open(log_file, 'r', encoding='utf-8') as f:
                for line in f:
                    try:
                        entry = json.loads(line.strip())
                        
                        # 时间过滤
                        entry_time = datetime.fromisoformat(entry['timestamp'])
                        if start_time and entry_time < start_time:
                            continue
                        if end_time and entry_time > end_time:
                            continue
                        
                        # 级别过滤
                        if level and entry['level'] != level:
                            continue
                        
                        results.append(entry)
                        
                        if len(results) >= limit:
                            break
                            
                    except json.JSONDecodeError:
                        continue
        
        # 按时间排序
        results.sort(key=lambda x: x['timestamp'], reverse=True)
        return results[:limit]
    
    def get_stats(self, date: Optional[str] = None) -> Dict[str, Any]:
        """获取日志统计"""
        if date is None:
            date = datetime.now().strftime('%Y%m%d')
        
        log_files = list(self.log_dir.glob(f"*_{date}.log"))
        
        stats = {
            "date": date,
            "total_logs": 0,
            "by_agent": {},
            "by_level": {
                "DEBUG": 0,
                "INFO": 0,
                "WARNING": 0,
                "ERROR": 0
            }
        }
        
        for log_file in log_files:
            agent_name = log_file.name.split('_')[0]
            
            with open(log_file, 'r', encoding='utf-8') as f:
                lines = f.readlines()
                
            stats["total_logs"] += len(lines)
            stats["by_agent"][agent_name] = len(lines)
            
            for line in lines:
                try:
                    entry = json.loads(line.strip())
                    level = entry.get('level', 'INFO')
                    if level in stats["by_level"]:
                        stats["by_level"][level] += 1
                except:
                    continue
        
        return stats


# 全局日志聚合器
_aggregator = None

def get_aggregator() -> LogAggregator:
    """获取日志聚合器单例"""
    global _aggregator
    if _aggregator is None:
        _aggregator = LogAggregator()
    return _aggregator


def create_logger(agent_id: str, agent_name: str) -> StructuredLogger:
    """创建日志记录器"""
    return StructuredLogger(agent_id, agent_name)


if __name__ == "__main__":
    # 测试日志系统
    logger = create_logger("test-001", "测试Agent")
    
    logger.info("系统启动")
    logger.task_start("task-001", "测试任务")
    logger.decision("选择模型", "kimi-coding/k2p5", "准确度高")
    logger.info("任务执行中", progress=50)
    logger.task_end("task-001", "成功", 1500)
    
    # 查询日志
    aggregator = get_aggregator()
    stats = aggregator.get_stats()
    print(f"\n日志统计: {json.dumps(stats, indent=2, ensure_ascii=False)}")
    
    logs = aggregator.query(limit=5)
    print(f"\n最近5条日志:")
    for log in logs:
        print(f"  [{log['level']}] {log['message']}")
