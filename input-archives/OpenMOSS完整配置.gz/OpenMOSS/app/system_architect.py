#!/usr/bin/env python3
"""
系统架构师 Agent - 自动执行脚本
运行: python3 system_architect.py [--auto]
"""

import json
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any

# 添加 app 目录到路径
sys.path.insert(0, "/Users/xiaowenzhi/OpenMOSS/app")
from logger import create_logger

class SystemArchitect:
    """系统架构师 Agent"""
    
    def __init__(self):
        self.agent_id = "system-architect-001"
        self.agent_name = "系统架构师"
        self.logger = create_logger(self.agent_id, self.agent_name)
        
        # 配置
        self.openmoss_root = Path("/Users/xiaowenzhi/OpenMOSS")
        self.workspace = Path("/Users/xiaowenzhi/.openclaw/agents/moss/workspace")
        self.output_dir = Path("/Users/xiaowenzhi/Desktop/MOSS输出")
        
    def log(self, message: str, **kwargs):
        """记录日志"""
        self.logger.info(message, **kwargs)
        print(f"[{datetime.now().strftime('%H:%M:%S')}] {message}")
    
    def run_architecture_review(self) -> Dict[str, Any]:
        """运行架构审查"""
        self.log("开始架构审查...")
        
        review_start = datetime.now()
        
        # 1. 检查Agent完整性
        agent_check = self._check_agent_integrity()
        
        # 2. 检查机制文档
        mechanism_check = self._check_mechanism_docs()
        
        # 3. 检查测试覆盖率
        test_check = self._check_test_coverage()
        
        # 4. 检查版本控制
        version_check = self._check_version_control()
        
        # 5. 检查日志系统
        log_check = self._check_log_system()
        
        review_duration = (datetime.now() - review_start).total_seconds()
        
        # 汇总结果
        report = {
            "review_time": datetime.now().isoformat(),
            "duration_seconds": review_duration,
            "overall_score": self._calculate_overall_score([
                agent_check["score"],
                mechanism_check["score"],
                test_check["score"],
                version_check["score"],
                log_check["score"]
            ]),
            "checks": {
                "agent_integrity": agent_check,
                "mechanism_docs": mechanism_check,
                "test_coverage": test_check,
                "version_control": version_check,
                "log_system": log_check
            },
            "issues": [],
            "recommendations": []
        }
        
        # 收集问题和建议
        for check_name, check_result in report["checks"].items():
            report["issues"].extend(check_result.get("issues", []))
            report["recommendations"].extend(check_result.get("recommendations", []))
        
        self.log(f"架构审查完成，总评分: {report['overall_score']}/100")
        
        return report
    
    def _check_agent_integrity(self) -> Dict[str, Any]:
        """检查Agent完整性"""
        self.log("检查Agent完整性...")
        
        required_agents = [
            "moss-planner-novel",
            "moss-executor-shendu",
            "moss-executor-pachong",
            "moss-executor-character",
            "moss-executor-number",
            "moss-executor-writer",
            "moss-reviewer-novel",
            "moss-executor-mirofish-reader",
            "moss-executor-feedback",
            "moss-executor-hr",
            "moss-patrol-enhanced",
        ]
        
        skills_dir = Path.home() / ".agents" / "skills"
        issues = []
        
        for agent in required_agents:
            agent_path = skills_dir / agent
            if not agent_path.exists():
                issues.append(f"缺少Agent Skill: {agent}")
        
        score = 100 - len(issues) * 5
        
        return {
            "score": max(0, score),
            "status": "通过" if len(issues) == 0 else "有问题",
            "issues": issues,
            "recommendations": [
                "定期检查Agent Skill完整性" if issues else "Agent完整性良好，保持"
            ]
        }
    
    def _check_mechanism_docs(self) -> Dict[str, Any]:
        """检查机制文档"""
        self.log("检查机制文档...")
        
        required_docs = [
            "MOSS_规划评审投票机制",
            "MOSS_动态分层规划机制",
            "MOSS_长文分层规划机制",
            "MOSS_信息可信度管理机制",
        ]
        
        mechanism_dir = self.output_dir / "00-系统文档" / "02-机制说明"
        issues = []
        
        for doc in required_docs:
            # 检查是否存在（支持 .md 和 .docx）
            found = False
            for ext in [".md", ".docx"]:
                if (mechanism_dir / f"{doc}{ext}").exists():
                    found = True
                    break
            if not found:
                issues.append(f"缺少机制文档: {doc}")
        
        score = 100 - len(issues) * 10
        
        return {
            "score": max(0, score),
            "status": "通过" if len(issues) == 0 else "有问题",
            "issues": issues,
            "recommendations": [
                "完善缺失的机制文档" if issues else "机制文档完整"
            ]
        }
    
    def _check_test_coverage(self) -> Dict[str, Any]:
        """检查测试覆盖率"""
        self.log("检查测试覆盖率...")
        
        test_dir = self.openmoss_root / "tests"
        issues = []
        
        # 检查测试框架是否存在
        if not (test_dir / "test_runner.py").exists():
            issues.append("缺少测试框架")
        
        # 运行测试获取覆盖率
        try:
            import subprocess
            result = subprocess.run(
                ["python3", "test_runner.py"],
                cwd=test_dir,
                capture_output=True,
                text=True,
                timeout=60
            )
            # 解析测试结果
            if "通过率" in result.stdout:
                # 提取通过率
                for line in result.stdout.split('\n'):
                    if '通过率' in line:
                        pass_rate_str = line.split(':')[-1].strip().replace('%', '')
                        try:
                            pass_rate = float(pass_rate_str)
                            if pass_rate < 80:
                                issues.append(f"测试通过率低于80%: {pass_rate}%")
                        except:
                            pass
                        break
        except Exception as e:
            issues.append(f"无法运行测试: {str(e)}")
        
        score = 100 - len(issues) * 15
        
        return {
            "score": max(0, score),
            "status": "通过" if len(issues) == 0 else "有问题",
            "issues": issues,
            "recommendations": [
                "提高测试覆盖率" if issues else "测试覆盖良好"
            ]
        }
    
    def _check_version_control(self) -> Dict[str, Any]:
        """检查版本控制"""
        self.log("检查版本控制...")
        
        issues = []
        
        # 检查 .git 目录
        if not (self.openmoss_root / ".git").exists():
            issues.append("未初始化Git版本控制")
        
        # 检查 .gitignore
        if not (self.openmoss_root / ".gitignore").exists():
            issues.append("缺少 .gitignore 文件")
        
        # 检查提交规范文档
        if not (self.openmoss_root / "docs" / "VERSION_MANAGEMENT.md").exists():
            issues.append("缺少版本管理规范文档")
        
        score = 100 - len(issues) * 15
        
        return {
            "score": max(0, score),
            "status": "通过" if len(issues) == 0 else "有问题",
            "issues": issues,
            "recommendations": [
                "建立完整的版本控制流程" if issues else "版本控制完善"
            ]
        }
    
    def _check_log_system(self) -> Dict[str, Any]:
        """检查日志系统"""
        self.log("检查日志系统...")
        
        issues = []
        
        # 检查日志模块
        if not (self.openmoss_root / "app" / "logger.py").exists():
            issues.append("缺少日志模块")
        
        # 检查仪表盘
        if not (self.openmoss_root / "app" / "dashboard.py").exists():
            issues.append("缺少日志仪表盘")
        
        # 检查日志目录
        log_dir = self.openmoss_root / "logs"
        if not log_dir.exists():
            issues.append("日志目录不存在")
        
        score = 100 - len(issues) * 15
        
        return {
            "score": max(0, score),
            "status": "通过" if len(issues) == 0 else "有问题",
            "issues": issues,
            "recommendations": [
                "完善统一日志系统" if issues else "日志系统完善"
            ]
        }
    
    def _calculate_overall_score(self, scores: List[int]) -> int:
        """计算总体评分"""
        if not scores:
            return 0
        return int(sum(scores) / len(scores))
    
    def generate_report(self, report: Dict[str, Any]) -> str:
        """生成审查报告"""
        report_time = datetime.now().strftime('%Y%m%d_%H%M%S')
        report_file = (
            self.output_dir / 
            "00-系统文档" / 
            "03-Agent配置" / 
            f"架构审查报告_{report_time}.md"
        )
        
        # 确保目录存在
        report_file.parent.mkdir(parents=True, exist_ok=True)
        
        # 计算风险等级
        score = report['overall_score']
        if score >= 90:
            risk_level = "🟢 低"
        elif score >= 70:
            risk_level = "🟡 中"
        else:
            risk_level = "🔴 高"
        
        # 生成问题部分
        def format_issues(check_result):
            issues = check_result.get('issues', [])
            if issues:
                return "**问题**:\n" + "\n".join(["- " + issue for issue in issues])
            return "**无问题** ✅"
        
        # 生成问题列表
        all_issues = report['issues']
        issues_section = "\n".join([f"{i+1}. {issue}" for i, issue in enumerate(all_issues)]) if all_issues else "**本次审查未发现严重问题** ✅"
        
        # 生成建议列表
        all_recs = report['recommendations']
        recs_section = "\n".join([f"{i+1}. {rec}" for i, rec in enumerate(all_recs)]) if all_recs else "**系统运行良好，暂无优化建议**"
        
        # 生成 Markdown 报告
        content = f"""# MOSS Agent 集群架构审查报告

**审查时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  
**审查者**: 系统架构师 Agent  
**集群版本**: v2.1.0

---

## 执行摘要

- **架构健康度**: {report['overall_score']}/100
- **审查耗时**: {report['duration_seconds']:.2f}秒
- **发现问题**: {len(report['issues'])}个
- **优化建议**: {len(report['recommendations'])}个
- **风险等级**: {risk_level}

---

## 详细检查结果

### 1. Agent 完整性

**评分**: {report['checks']['agent_integrity']['score']}/100  
**状态**: {report['checks']['agent_integrity']['status']}

{format_issues(report['checks']['agent_integrity'])}

### 2. 机制文档

**评分**: {report['checks']['mechanism_docs']['score']}/100  
**状态**: {report['checks']['mechanism_docs']['status']}

{format_issues(report['checks']['mechanism_docs'])}

### 3. 测试覆盖率

**评分**: {report['checks']['test_coverage']['score']}/100  
**状态**: {report['checks']['test_coverage']['status']}

{format_issues(report['checks']['test_coverage'])}

### 4. 版本控制

**评分**: {report['checks']['version_control']['score']}/100  
**状态**: {report['checks']['version_control']['status']}

{format_issues(report['checks']['version_control'])}

### 5. 日志系统

**评分**: {report['checks']['log_system']['score']}/100  
**状态**: {report['checks']['log_system']['status']}

{format_issues(report['checks']['log_system'])}

---

## 发现的问题

{issues_section}

---

## 优化建议

{recs_section}

---

## 附录

### 原始数据

```json
{json.dumps(report, indent=2, ensure_ascii=False)}
```

---

**报告生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  
**下次审查**: 2026-04-01
"""
        
        report_file.write_text(content, encoding='utf-8')
        
        return str(report_file)
    
    def run(self):
        """运行系统架构师"""
        self.log("="*60)
        self.log("系统架构师 Agent 启动")
        self.log("="*60)
        
        # 执行架构审查
        report = self.run_architecture_review()
        
        # 生成报告
        report_file = self.generate_report(report)
        
        self.log("="*60)
        self.log(f"架构审查完成")
        self.log(f"健康度评分: {report['overall_score']}/100")
        self.log(f"报告已保存: {report_file}")
        self.log("="*60)
        
        return report


def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description='系统架构师 Agent')
    parser.add_argument('--auto', '-a', action='store_true', help='自动模式')
    
    args = parser.parse_args()
    
    architect = SystemArchitect()
    
    if args.auto:
        # 自动模式：只输出结果，不交互
        report = architect.run()
        sys.exit(0 if report['overall_score'] >= 70 else 1)
    else:
        # 交互模式
        report = architect.run()


if __name__ == "__main__":
    main()
