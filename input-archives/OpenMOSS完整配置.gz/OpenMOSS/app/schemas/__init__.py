"""
Pydantic schemas
"""
