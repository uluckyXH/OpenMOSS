# 版本管理规范

## Git 分支策略

```
main                 # 主分支 - 稳定版本
├── develop          # 开发分支 - 日常开发
├── feature/*        # 功能分支 - 新功能开发
├── hotfix/*         # 热修复分支 - 紧急修复
└── release/*        # 发布分支 - 版本发布
```

## 提交规范

### 提交信息格式
```
<type>(<scope>): <subject>

<body>

<footer>
```

### Type 类型

| 类型 | 说明 | 示例 |
|------|------|------|
| `feat` | 新功能 | `feat(agent): 新增系统架构师Agent` |
| `fix` | 修复 | `fix(security): 修复脚本注入漏洞` |
| `docs` | 文档 | `docs(mechanism): 更新投票评审机制` |
| `style` | 格式 | `style(format): 统一代码格式` |
| `refactor` | 重构 | `refactor(core): 重构调度系统` |
| `test` | 测试 | `test(unit): 添加单元测试` |
| `chore` | 构建 | `chore(deps): 更新依赖` |

### Scope 范围

- `agent` - Agent 相关
- `mechanism` - 机制相关
- `security` - 安全相关
- `docs` - 文档相关
- `test` - 测试相关
- `core` - 核心代码

### 示例

```bash
# 新增功能
feat(agent): 新增系统架构师Agent

- 自动审查集群架构
- 生成升级建议报告
- 每月定期执行

Closes #123

# 修复问题
fix(security): 修复脚本注入漏洞

- 添加输入验证
- 使用参数化命令
- 限制文件类型

Security: CVE-2026-XXXX

# 更新文档
docs(mechanism): 更新投票评审机制

- 调整通过线为80分
- 新增文笔专家评审维度
- 更新评分权重
```

## 版本号规范

采用 [语义化版本](https://semver.org/lang/zh-CN/)

```
主版本号.次版本号.修订号

例如: 2.1.3
```

### 版本升级规则

- **主版本号**：不兼容的 API 修改
- **次版本号**：向下兼容的功能新增
- **修订号**：向下兼容的问题修复

### 标签管理

```bash
# 创建版本标签
git tag -a v2.1.0 -m "Release version 2.1.0"

# 推送标签
git push origin v2.1.0

# 推送所有标签
git push origin --tags
```

## 机制文档版本管理

所有机制文档纳入版本控制：

```
~/Desktop/MOSS输出/00-系统文档/
├── 01-工作流程/
│   └── MOSS_完整工作流程_v1.2.md
├── 02-机制说明/
│   ├── MOSS_规划评审投票机制_v2.1.md
│   ├── MOSS_动态分层规划机制_v1.0.md
│   └── ...
└── 03-Agent配置/
    └── ...
```

### 版本更新流程

1. 在 `develop` 分支修改机制文档
2. 更新文档头部的版本号和变更记录
3. 提交 PR 到 `main` 分支
4. 审查通过后合并
5. 打版本标签

### 文档头部模板

```markdown
# 机制名称

**版本**: v2.1.0  
**更新时间**: 2026-03-16  
**状态**: 生效中

## 版本历史

### v2.1.0 (2026-03-16)
- 调整通过线: 70分 → 80分
- 新增文笔专家评审维度

### v2.0.0 (2026-03-10)
- 重构评审流程
- 新增快速评审通道

### v1.0.0 (2026-03-01)
- 初始版本

---

## 正文内容...
```

## CI/CD 流程

```
开发者提交代码
    ↓
GitHub Actions 触发
    ↓
├── 运行单元测试
├── 运行集成测试
├── 检查代码规范
└── 生成测试报告
    ↓
测试通过?
    ↓
是 → 合并到 main 分支
    ↓
自动部署到测试环境
    ↓
人工验收
    ↓
打版本标签
    ↓
部署到生产环境
```

## 回滚策略

### 发现问题

```bash
# 1. 回滚到上一个稳定版本
git revert HEAD

# 2. 或重置到指定版本
git reset --hard v2.0.0

# 3. 强制推送（慎用）
git push origin main --force
```

### 机制文档回滚

```bash
# 查看历史版本
git log --oneline ~/Desktop/MOSS输出/00-系统文档/

# 恢复到指定版本
git checkout v2.0.0 -- ~/Desktop/MOSS输出/00-系统文档/

# 提交回滚
git commit -m "revert(mechanism): 回滚机制到 v2.0.0"
```

---

**制定时间**: 2026-03-16  
**负责人**: 小墨 🦋
