## 📚 知识库访问指南（修正版）

### 知识库位置

知识库位于你的本地文件系统：

```
/Users/xiaowenzhi/OpenMOSS/knowledge-base/
```

### 访问方法

**你必须使用`read`工具读取知识库文件**：

```
# 读取规则类知识
read /Users/xiaowenzhi/OpenMOSS/knowledge-base/rules/de-ai-guidelines.md
read /Users/xiaowenzhi/OpenMOSS/knowledge-base/rules/review-criteria-95.md
read /Users/xiaowenzhi/OpenMOSS/knowledge-base/rules/v6.0-workflow-overview.md

# 读取索引
read /Users/xiaowenzhi/OpenMOSS/knowledge-base/indexes/master-index.md

# 读取激励机制
read /Users/xiaowenzhi/OpenMOSS/knowledge-base/query-incentive-system.md
```

### 关键文件速查

| 你需要的内容 | 读取命令 |
|-------------|---------|
| 95分审查标准详解 | `read /Users/xiaowenzhi/OpenMOSS/knowledge-base/rules/review-criteria-95.md` |
| 去AI味完整指南 | `read /Users/xiaowenzhi/OpenMOSS/knowledge-base/rules/de-ai-guidelines.md` |
| v6.0流程概览 | `read /Users/xiaowenzhi/OpenMOSS/knowledge-base/rules/v6.0-workflow-overview.md` |
| 知识库总索引 | `read /Users/xiaowenzhi/OpenMOSS/knowledge-base/indexes/master-index.md` |
| 查询激励机制 | `read /Users/xiaowenzhi/OpenMOSS/knowledge-base/query-incentive-system.md` |

### 读取后必须反馈

```markdown
【已查阅知识库】
- 读取文件：/Users/xiaowenzhi/OpenMOSS/knowledge-base/rules/de-ai-guidelines.md
- 关键收获：
  1. 严禁"首先/其次/综上所述"
  2. 每1000字1-2处错别字
  3. 短句占60%以上
- 应用情况：已删除文中"首先"，改为"一开始"
```

### ⚠️ 重要提醒

- ❌ 不要写"kb:xxx"，这不是有效的文件路径
- ✅ 必须使用`read`工具读取完整路径
- ✅ 读取后必须反馈【已查阅知识库】
- ✅ 不读取知识库将扣5分

