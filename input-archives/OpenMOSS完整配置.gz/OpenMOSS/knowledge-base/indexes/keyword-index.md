# 关键词索引

## A

### AI化表达
- 定义：使用典型的AI化词汇和句式
- 禁用词：首先、其次、更关键的是、众所周知
- 参考：kb:rules/de-ai-guidelines
- 示例：kb:examples/bad-examples/ai-flavor-heavy

## D

### 对话技巧
- 紧张对话：kb:examples/good-examples/dialogue-tension
- 修改对比：kb:examples/before-after/revision-02-dialogue
- 技巧：用动作打断、不说满、有潜台词

## G

### 古代背景
- 秦朝：kb:references/research-cache/qin-dynasty-facts
- 唐朝：kb:references/research-cache/tang-dynasty-culture

## H

### 钩子设计
- 类型：信息钩子、选择钩子、警告钩子、画面钩子
- 参考：kb:examples/good-examples/hook-chapter-ending

## J

### 惊吓描写
- 五感描写：kb:references/writing-techniques/five-senses-description
- 心理恐惧：kb:examples/good-examples/psychological-fear

## K

### 开篇技巧
- 钩子：kb:examples/good-examples/hook-chapter-ending
- 人物出场：kb:examples/good-examples/character-intro-mysterious

## L

### 类型指南
- 修仙：kb:references/genre-guides/xianxia-guide
- 悬疑：kb:references/genre-guides/mystery-guide

## P

### 评价标准
- 95分标准：kb:rules/review-criteria-95
- 审查清单：kb:agent-specific/reviewer-checklist

### 心理刻画
- 恐惧：kb:examples/good-examples/psychological-fear
- 冲突：kb:examples/good-examples/psychological-conflict

## Q

### 去AI味
- 完整指南：kb:rules/de-ai-guidelines
- 反面示例：kb:examples/bad-examples/ai-flavor-heavy
- 修改对比：kb:examples/before-after/revision-01-scene

### 情感表达
- Show Don't Tell：kb:references/writing-techniques/show-dont-tell

## R

### 人物出场
- 神秘人物：kb:examples/good-examples/character-intro-mysterious

## S

### 场景描写
- 优秀示例：kb:examples/good-examples/scene-rainy-night
- 五感技巧：kb:references/writing-techniques/five-senses-description

### 输出格式
- v6.0流程：kb:rules/v6.0-workflow-overview
- 文件命名：见AGENTS.md

## W

### 文笔技巧
- Show Don't Tell：kb:references/writing-techniques/show-dont-tell
- 五感描写：kb:references/writing-techniques/five-senses-description

### 作家技能
- 技能库：kb:agent-specific/writer-skills

## X

### 悬疑技巧
- 类型指南：kb:references/genre-guides/mystery-guide
- 紧张对话：kb:examples/good-examples/dialogue-tension

### 修仙技巧
- 类型指南：kb:references/genre-guides/xianxia-guide

## Y

### 应用场景
- 雨夜场景：kb:examples/good-examples/scene-rainy-night

## Z

### 章末钩子
- 设计技巧：kb:examples/good-examples/hook-chapter-ending

## 数字

### 45特征
- 去AI味45特征：kb:rules/de-ai-guidelines

### 95分
- 审查标准：kb:rules/review-criteria-95

### 9维度
- 审查维度：kb:agent-specific/reviewer-checklist

## 其他

### 红线清单
- 17条红线：kb:rules/redlines

### 常见错误
- 避免方法：kb:rules/common-mistakes

### 查询激励
- 积分系统：kb:query-incentive-system
