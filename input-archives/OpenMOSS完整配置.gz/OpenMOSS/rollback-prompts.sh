#!/bin/bash
# 知识库试点回退脚本
# 如果出现问题，执行此脚本恢复原提示词

BACKUP_DIR="$HOME/OpenMOSS/prompts/role-backup-$(ls -t $HOME/OpenMOSS/prompts/ | grep role-backup | head -1 | cut -d- -f3-)"
ROLE_DIR="$HOME/OpenMOSS/prompts/role"

echo "=== OpenMOSS提示词回退 ==="
echo ""

if [ ! -d "$BACKUP_DIR" ]; then
    echo "❌ 错误：找不到备份目录"
    echo "备份目录应位于：$HOME/OpenMOSS/prompts/role-backup-YYYYMMDD-HHMMSS"
    exit 1
fi

echo "备份来源：$BACKUP_DIR"
echo ""

# 确认回退
echo "⚠️ 警告：此操作将恢复原始提示词，覆盖当前瘦身版！"
read -p "确认回退？(输入 YES 确认): " confirm

if [ "$confirm" != "YES" ]; then
    echo "❌ 回退已取消"
    exit 0
fi

# 执行回退
echo ""
echo "正在回退..."

# 备份当前状态（以防万一）
CURRENT_BACKUP="$HOME/OpenMOSS/prompts/role-current-$(date +%Y%m%d-%H%M%S)"
cp -r "$ROLE_DIR" "$CURRENT_BACKUP"
echo "✅ 当前状态已备份到：$CURRENT_BACKUP"

# 恢复原始提示词
rm -rf "$ROLE_DIR"/*
cp -r "$BACKUP_DIR"/* "$ROLE_DIR/"

echo "✅ 提示词已恢复到备份状态"
echo ""
echo "恢复的文件数：$(find $ROLE_DIR -name '*.md' | wc -l)个"
echo ""
echo "🔄 知识库试点已回退，系统恢复到原始状态"
